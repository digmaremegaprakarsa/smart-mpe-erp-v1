import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const chatWithGemini = async (prompt: string, context?: string): Promise<string> => {
  try {
    const fullPrompt = context 
      ? `Context: ${context}\n\nUser Question: ${prompt}`
      : prompt;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: fullPrompt,
      config: {
        systemInstruction: "You are an expert technical assistant for an electric motor repair workshop (bengkel dinamo). You help technicians diagnose issues and admins draft professional emails.",
      }
    });
    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "Maaf, terjadi kesalahan saat menghubungi AI assistant.";
  }
};

export const analyzeMotorImage = async (base64Image: string, prompt: string): Promise<string> => {
  try {
    // Clean base64 string if it contains metadata prefix
    const data = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: data
            }
          },
          {
            text: prompt || "Analyze this image of an electric motor. Identify the nameplate data if visible, or describe the visual condition/damage."
          }
        ]
      }
    });
    return response.text || "Could not analyze image.";
  } catch (error) {
    console.error("Gemini Vision Error:", error);
    return "Gagal menganalisa gambar.";
  }
};