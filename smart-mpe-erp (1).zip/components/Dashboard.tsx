import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { MotorData, MotorStatus } from '../types';
import { motion } from 'framer-motion';
import { PhotoGalleryModal } from './PhotoGalleryModal';

interface DashboardProps {
  data: MotorData[];
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444']; 

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  
  const [selectedGalleryMotor, setSelectedGalleryMotor] = useState<MotorData | null>(null);

  const totalUnits = data.length;
  // Workshop KPIs
  const onProgress = data.filter(d => d.status === MotorStatus.ON_PROGRESS).length;
  const readyToShip = data.filter(d => d.status === MotorStatus.KIRIM).length;
  
  // Commercial KPIs
  const waitingPO = data.filter(d => d.status === MotorStatus.PENDING || (d.status === MotorStatus.ON_PROGRESS && !d.nomorPO)).length;
  
  // Schedule KPIs
  const today = new Date().toISOString().split('T')[0];
  const overdue = data.filter(d => d.tanggalKirim && d.tanggalKirim < today && d.status !== MotorStatus.KIRIM).length;

  // Filter Data for Gallery (Items that have photos)
  const galleryItems = data.filter(d => d.fotoUrls && d.fotoUrls.length > 0);

  // Helper to simulate Cloudinary Thumbnail (Medium size for Dashboard Cards)
  const getCardThumbnail = (url: string) => {
      if (!url) return '';
      if (url.includes('cloudinary.com')) {
          return url.replace("/upload/", "/upload/w_400,h_300,c_fill,g_auto/");
      }
      return url;
  };

  const statusCounts = [
    { name: 'Active Jobs', value: onProgress },
    { name: 'Completed', value: readyToShip },
    { name: 'Pending/Hold', value: data.filter(d => d.status === MotorStatus.PENDING).length },
  ];

  const monthlyData = [
    { name: 'Jan', masuk: 12, keluar: 10 },
    { name: 'Feb', masuk: 15, keluar: 8 },
    { name: 'Mar', masuk: 18, keluar: 15 },
    { name: 'Apr', masuk: 10, keluar: 12 },
    { name: 'Mei', masuk: 20, keluar: 18 },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const Card = ({ title, value, colorClass, bgClass, icon }: any) => (
      <motion.div 
        variants={itemVariants}
        className="glass rounded-3xl p-6 relative overflow-hidden group border-l-4 border-l-transparent hover:border-l-indigo-500 transition-all"
      >
          <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500`}>
             <div className={`w-24 h-24 rounded-full ${bgClass}`}></div>
          </div>
          
          <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                  <div className={`p-2 rounded-xl bg-white/50 ${colorClass}`}>
                      {icon}
                  </div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">{title}</p>
              </div>
              <h3 className={`text-4xl font-black ${colorClass} tracking-tight`}>{value}</h3>
          </div>
      </motion.div>
  )

  return (
    <>
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="space-y-6 pb-8"
    >
      {/* High Level KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card 
            title="Total Units" 
            value={totalUnits} 
            colorClass="text-slate-800"
            bgClass="bg-slate-800"
            icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>}
        />
        <Card 
            title="In Workshop" 
            value={onProgress} 
            colorClass="text-blue-600"
            bgClass="bg-blue-600"
            icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" /></svg>}
        />
        <Card 
            title="Waiting PO" 
            value={waitingPO} 
            colorClass="text-amber-500"
            bgClass="bg-amber-500"
            icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}
        />
        <Card 
            title="Overdue" 
            value={overdue} 
            colorClass="text-red-500"
            bgClass="bg-red-500"
            icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <motion.div variants={itemVariants} className="glass rounded-[2rem] p-8 flex flex-col min-w-0">
          <h4 className="text-xl font-bold mb-6 text-slate-800 flex items-center gap-2">
            <span className="w-2 h-8 bg-indigo-500 rounded-full"></span>
            Job Distribution
          </h4>
          <div className="w-full h-[300px] relative">
            <ResponsiveContainer width="100%" height="100%" debounce={100}>
              <PieChart>
                <Pie
                  data={statusCounts}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={100}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                  cornerRadius={8}
                >
                  {statusCounts.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} style={{filter: 'drop-shadow(0px 10px 10px rgba(0,0,0,0.1))'}} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', background: 'rgba(255,255,255,0.9)', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)', fontWeight: 'bold' }}
                />
                <Legend verticalAlign="bottom" height={36} iconType="circle" iconSize={8}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Monthly Performance */}
        <motion.div variants={itemVariants} className="glass rounded-[2rem] p-8 flex flex-col min-w-0">
          <h4 className="text-xl font-bold mb-6 text-slate-800 flex items-center gap-2">
            <span className="w-2 h-8 bg-emerald-500 rounded-full"></span>
            Workshop Throughput
          </h4>
          <div className="w-full h-[300px] relative">
            <ResponsiveContainer width="100%" height="100%" debounce={100}>
              <BarChart
                data={monthlyData}
                barSize={12}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#cbd5e1" strokeOpacity={0.4} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12, fontWeight: 600}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12, fontWeight: 600}} />
                <Tooltip cursor={{fill: '#f1f5f9'}} contentStyle={{ borderRadius: '16px', border: 'none', background: 'rgba(255,255,255,0.9)', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' }} />
                <Bar dataKey="masuk" name="Incoming" fill="#6366f1" radius={[10, 10, 10, 10]} />
                <Bar dataKey="keluar" name="Completed" fill="#10b981" radius={[10, 10, 10, 10]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* NEW: RECENT DOCUMENTATION GALLERY */}
      <motion.div variants={itemVariants} className="glass rounded-[2rem] p-8">
         <div className="flex items-center justify-between mb-6">
            <h4 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                Recent Documentation
            </h4>
            <span className="bg-amber-100 text-amber-600 px-3 py-1 rounded-lg text-xs font-bold">
                {galleryItems.length} Gallery Items
            </span>
         </div>
         
         {galleryItems.length > 0 ? (
             <div className="flex gap-6 overflow-x-auto pb-6 pt-2 snap-x scrollbar-hide">
                {galleryItems.map((item, idx) => (
                    <motion.div 
                        key={item.kodeBarang}
                        whileHover={{ scale: 1.02, y: -5 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSelectedGalleryMotor(item)}
                        className="snap-start min-w-[280px] h-[320px] bg-white rounded-3xl shadow-sm border border-white hover:shadow-xl transition-all cursor-pointer relative overflow-hidden group flex flex-col"
                    >
                        {/* Image Area */}
                        <div className="h-[200px] w-full relative overflow-hidden">
                            <img 
                                src={getCardThumbnail(item.fotoUrls?.[0] || '')} 
                                alt={item.kodeBarang}
                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>
                            
                            {/* WO Badge on Image */}
                            <div className="absolute top-4 left-4">
                                <span className="bg-white/90 backdrop-blur text-slate-800 text-[10px] font-black px-2 py-1 rounded-md shadow-sm uppercase tracking-wider">
                                    WO: {item.kodeBarang}
                                </span>
                            </div>

                            {/* Photo Count Badge */}
                            <div className="absolute bottom-4 right-4 flex items-center gap-1 text-white bg-black/40 backdrop-blur-md px-2 py-1 rounded-lg">
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                <span className="text-[10px] font-bold">{item.fotoUrls?.length}</span>
                            </div>
                        </div>

                        {/* Content Area */}
                        <div className="p-5 flex-1 flex flex-col justify-between bg-white relative z-10">
                            <div>
                                <h5 className="font-bold text-slate-800 text-lg truncate mb-1">{item.namaPerusahaan}</h5>
                                <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">{item.jenisMotor}</p>
                            </div>
                            
                            <div className="flex items-center justify-between mt-3">
                                <span className={`text-[10px] font-bold px-2 py-1 rounded border ${
                                    item.status === MotorStatus.KIRIM ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 
                                    item.status === MotorStatus.ON_PROGRESS ? 'bg-blue-50 border-blue-100 text-blue-600' : 'bg-slate-50 border-slate-100 text-slate-500'
                                }`}>
                                    {item.status}
                                </span>
                                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                ))}
             </div>
         ) : (
             <div className="flex flex-col items-center justify-center py-12 bg-white/40 rounded-3xl border border-dashed border-slate-300">
                 <div className="bg-slate-100 p-4 rounded-full mb-3">
                     <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                 </div>
                 <p className="text-slate-500 font-bold text-sm">Belum ada dokumentasi tersimpan</p>
             </div>
         )}

      </motion.div>

    </motion.div>

    {/* Gallery Modal Integration */}
    {selectedGalleryMotor && (
        <PhotoGalleryModal 
            isOpen={!!selectedGalleryMotor} 
            onClose={() => setSelectedGalleryMotor(null)}
            imageUrls={selectedGalleryMotor.fotoUrls || []}
            title={selectedGalleryMotor.kodeBarang}
        />
    )}
    </>
  );
};