import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PhotoGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrls: string[];
  title: string; // This is the WO Number
}

export const PhotoGalleryModal: React.FC<PhotoGalleryModalProps> = ({ isOpen, onClose, imageUrls, title }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentImageIndex(0);
      document.body.style.overflow = 'hidden'; 
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; }
  }, [isOpen]);

  if (!isOpen) return null;

  // --- CLOUDINARY OPTIMIZATION SIMULATION ---
  // In real app, we transform the URL string to request a smaller version for thumbnails
  const getThumbnailUrl = (url: string) => {
      if (url.includes('cloudinary.com')) {
          // Add 'w_150,c_scale' to the transformation path
          return url.replace("/upload/", "/upload/w_150,c_scale/");
      }
      return url;
  };

  const handleDownloadZip = () => {
      setIsDownloading(true);
      
      // --- BACKEND API CALL SIMULATION ---
      // Real Call: window.location.href = `http://api.backend.com/api/motor/${title}/download-zip`;
      
      setTimeout(() => {
          setIsDownloading(false);
          const link = document.createElement('a');
          link.href = '#';
          link.download = `Foto_Motor_${title.replace(/\s/g, '_')}.zip`; 
          document.body.appendChild(link);
          
          alert(`⬇️ Memulai Download: Foto_Motor_${title}.zip\n(Mengambil dari Cloudinary & Compressing...)`);
          
          document.body.removeChild(link);
      }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-md"
            onClick={onClose}
        >
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-2xl overflow-hidden w-full max-w-6xl shadow-2xl flex flex-col md:flex-row h-[85vh] relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Mobile Header / Close */}
            <div className="absolute top-4 right-4 z-20 flex gap-2">
                 <button 
                    onClick={onClose}
                    className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full backdrop-blur-md transition-colors"
                >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>

            {/* MAIN IMAGE VIEW */}
            <div className="flex-1 bg-black flex items-center justify-center p-4 relative group">
                <div className="absolute top-4 left-4 z-10 bg-black/50 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
                     <p className="text-white text-xs font-bold tracking-widest">
                         NO. WO: <span className="text-emerald-400">{title}</span>
                     </p>
                </div>

                {imageUrls.length > 0 ? (
                    <motion.img 
                        key={currentImageIndex}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        src={imageUrls[currentImageIndex]} 
                        alt={`Evidence ${currentImageIndex + 1}`}
                        className="max-h-full max-w-full object-contain shadow-2xl"
                    />
                ) : (
                    <div className="text-white/50 flex flex-col items-center">
                        <p>No Images Available</p>
                    </div>
                )}
                
                {/* Navigation Arrows */}
                {imageUrls.length > 1 && (
                    <>
                        <button 
                            onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(prev => prev === 0 ? imageUrls.length - 1 : prev - 1); }}
                            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full backdrop-blur-md transition-all"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                        </button>
                        <button 
                             onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(prev => prev === imageUrls.length - 1 ? 0 : prev + 1); }}
                            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full backdrop-blur-md transition-all"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                        </button>
                    </>
                )}
            </div>

            {/* SIDEBAR: THUMBNAILS & ACTIONS */}
            <div className="w-full md:w-80 bg-white flex flex-col border-l border-slate-200">
                <div className="p-6 border-b border-slate-100 bg-slate-50">
                    <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">Galeri Dokumentasi</h3>
                    <h2 className="text-xl font-black text-slate-800 break-words">{title}</h2>
                    <p className="text-slate-400 text-xs font-medium mt-1">
                        Folder: motor_inventaris/{title}
                    </p>
                </div>

                <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-slate-50/50">
                    <div className="grid grid-cols-4 md:grid-cols-2 gap-3">
                        {imageUrls.map((url, idx) => (
                            <div 
                                key={idx}
                                onClick={() => setCurrentImageIndex(idx)}
                                className={`aspect-square rounded-lg overflow-hidden cursor-pointer border-2 transition-all relative ${
                                    currentImageIndex === idx ? 'border-emerald-500 ring-2 ring-emerald-100' : 'border-transparent hover:border-slate-300'
                                }`}
                            >
                                <img 
                                    src={getThumbnailUrl(url)} 
                                    alt={`Thumb ${idx}`} 
                                    className="w-full h-full object-cover"
                                />
                            </div>
                        ))}
                    </div>
                </div>

                {/* FOOTER: DOWNLOAD ZIP */}
                <div className="p-4 border-t border-slate-200 bg-white">
                    <button 
                        onClick={handleDownloadZip}
                        disabled={isDownloading || imageUrls.length === 0}
                        className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                            isDownloading 
                            ? 'bg-slate-100 text-slate-400 cursor-wait' 
                            : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-500/20'
                        }`}
                    >
                        {isDownloading ? (
                            <>
                                <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Zipping...
                            </>
                        ) : (
                            <>
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                Download Semua (ZIP)
                            </>
                        )}
                    </button>
                    <div className="flex justify-center mt-2 gap-2 text-[10px] text-slate-400">
                        <span className="flex items-center gap-1">
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            Secure
                        </span>
                        <span className="flex items-center gap-1">
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                            FastAPI
                        </span>
                    </div>
                </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
