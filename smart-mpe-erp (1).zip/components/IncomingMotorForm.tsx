import React, { useState, useRef, useEffect } from 'react';
import { MotorData, MotorStatus } from '../types';
import { motion } from 'framer-motion';

interface IncomingMotorFormProps {
  onSave: (data: MotorData) => void;
  onCancel: () => void;
}

// Configuration for WO Logic
const SALES_CODES = [
    { code: 'P', label: 'P - Pusat' },
    { code: 'I', label: 'I - Ine' },
    { code: 'H', label: 'H - Hendar' },
    { code: 'R', label: 'R - Rully' }
];

const YEAR_CODES: { [key: number]: string } = {
    2025: 'K',
    2026: 'L',
    2027: 'M',
    2028: 'N',
    2029: 'O',
    2030: 'P'
};

export const IncomingMotorForm: React.FC<IncomingMotorFormProps> = ({ onSave, onCancel }) => {
  // WO Parts State
  const [woParts, setWoParts] = useState({
      sales: 'P',
      sequence: '',
      year: 'K' // Default, updated via useEffect
  });

  // Initial State optimized for "Motor Datang"
  const [formData, setFormData] = useState<Partial<MotorData>>({
    kodeBarang: '', // Computed from woParts
    namaPerusahaan: '',
    dayaKW: '',
    teganganVolt: '',
    rpm: '',
    arusAmpere: '',
    status: MotorStatus.ON_PROGRESS,
    fotoUrls: [],
    tanggalMasuk: new Date().toISOString().split('T')[0],
    jenisMotor: 'AC MOTOR',
    merk: '',
    serialNumber: '',
    statusFormPutih: 'BELUM',
    statusFormBiru: 'BELUM',
    dataMegger: 'BELUM',
    infoCustomer: '',
    dokumentasiUrl: '',
    tanggalKirim: '',
    noSuratJalan: '',
    nomorPenawaran: '',
    tanggalPenawaran: '',
    nomorPO: ''
  });

  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- AUTO SET YEAR CODE ---
  useEffect(() => {
      const currentYear = new Date().getFullYear();
      const code = YEAR_CODES[currentYear] || '?'; // Default to ? if out of range
      setWoParts(prev => ({ ...prev, year: code }));
  }, []);

  // --- SYNC WO PARTS TO FORM DATA ---
  useEffect(() => {
      // Format: [SALES] [SEQUENCE] [YEAR] -> "P 1024 K"
      const generatedWO = `${woParts.sales} ${woParts.sequence} ${woParts.year}`.trim();
      setFormData(prev => ({ ...prev, kodeBarang: generatedWO }));
  }, [woParts]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleWoChange = (field: 'sales' | 'sequence', value: string) => {
      setWoParts(prev => ({ ...prev, [field]: value }));
  };

  // --- 1. HANDLE PHOTO SELECTION ---
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
        const filesArray = Array.from(e.target.files);
        
        if (selectedFiles.length + filesArray.length > 10) {
            alert("⚠️ Maksimal 10 foto yang diperbolehkan.");
            return;
        }

        setSelectedFiles(prev => [...prev, ...filesArray]);
        
        const newPreviews = filesArray.map((file) => URL.createObjectURL(file as Blob));
        setPreviewUrls(prev => [...prev, ...newPreviews]);
    }
  };

  const removePhoto = (index: number) => {
      setSelectedFiles(prev => prev.filter((_, i) => i !== index));
      setPreviewUrls(prev => prev.filter((_, i) => i !== index));
  };

  // --- 2. SUBMIT & UPLOAD SIMULATION ---
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!woParts.sequence) { alert("Nomor urut WO wajib diisi!"); return; }

    if (selectedFiles.length < 4 || selectedFiles.length > 10) {
        alert("⚠️ Syarat Penerimaan Awal: Wajib lampirkan 4 - 10 foto dokumentasi fisik motor.");
        return;
    }

    setIsUploading(true);

    // Simulate Network/Cloudinary Upload Delay
    await new Promise(resolve => setTimeout(resolve, 2000)); 

    // --- DATA SANITIZATION & SYNC ---
    // Pastikan data yang dikirim ke 'onSave' (App.tsx) bersih dan bertipe benar
    const finalData: MotorData = {
        ...formData as MotorData,
        
        // 1. Ensure WO ID is strictly from the generator parts
        kodeBarang: `${woParts.sales} ${woParts.sequence} ${woParts.year}`.trim(),
        
        // 2. Convert numeric strings to actual numbers for Dashboard charts
        dayaKW: formData.dayaKW ? Number(formData.dayaKW) : 0,
        teganganVolt: formData.teganganVolt ? Number(formData.teganganVolt) : 0,
        rpm: formData.rpm ? Number(formData.rpm) : 0,
        arusAmpere: formData.arusAmpere ? Number(formData.arusAmpere) : 0,
        
        // 3. Normalize Company Name
        namaPerusahaan: (formData.namaPerusahaan || '').toUpperCase(),
        
        // 4. Attach Photos
        fotoUrls: previewUrls,
        dokumentasiUrl: previewUrls[0] || '', // Cover image
        
        // 5. Defaults
        status: MotorStatus.ON_PROGRESS,
        jenisMotor: formData.jenisMotor || 'AC MOTOR'
    };

    setIsUploading(false);
    onSave(finalData); // Sync to Main State in App.tsx
  };

  // Styles
  const inputGroupStyle = "bg-white/50 border border-white/60 rounded-xl p-1 focus-within:ring-2 focus-within:ring-emerald-400 focus-within:bg-white transition-all shadow-sm";
  const inputStyle = "w-full bg-transparent border-none text-slate-800 font-bold placeholder-slate-400 focus:ring-0 outline-none p-3 text-sm";
  const labelStyle = "block text-[10px] font-extrabold text-slate-500 uppercase tracking-widest mb-1.5 ml-1";

  return (
    <div className="flex justify-center items-center h-full pb-10 px-4">
        <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-[2rem] shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col md:flex-row h-auto md:h-[600px] border border-white/60"
        >
            {/* LEFT SIDE: FORM INPUT */}
            <div className="flex-1 p-8 overflow-y-auto custom-scrollbar bg-gradient-to-br from-white/40 to-white/10">
                <div className="mb-6 border-b border-slate-200 pb-4">
                    <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                        <span className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                        </span>
                        WO Motor Datang
                    </h2>
                    <p className="text-xs text-slate-500 font-bold mt-1 ml-10 uppercase tracking-wide">Input Data Teknis Awal</p>
                </div>

                <form id="woForm" onSubmit={handleSubmit} className="space-y-5">
                    
                    {/* Primary ID: Work Order Logic */}
                    <div className="bg-white/40 p-4 rounded-2xl border border-white/50">
                        <label className={labelStyle}>Nomor Work Order (WO)</label>
                        <div className="flex gap-2 items-center">
                            {/* 1. SALES CODE */}
                            <div className="w-1/3 min-w-[100px]">
                                <select 
                                    value={woParts.sales}
                                    onChange={(e) => handleWoChange('sales', e.target.value)}
                                    className={`${inputGroupStyle} w-full text-sm font-bold text-slate-800 outline-none p-3 cursor-pointer`}
                                >
                                    {SALES_CODES.map(s => (
                                        <option key={s.code} value={s.code}>{s.label}</option>
                                    ))}
                                </select>
                                <p className="text-[9px] text-slate-400 mt-1 ml-1">Kode Sales</p>
                            </div>

                            {/* 2. SEQUENCE NUMBER */}
                            <div className="flex-1">
                                <input 
                                    type="text"
                                    value={woParts.sequence}
                                    onChange={(e) => handleWoChange('sequence', e.target.value)}
                                    placeholder="No. Urut (Ex: 1024)"
                                    className={`${inputGroupStyle} w-full text-sm font-bold text-slate-800 p-3 outline-none`}
                                    autoFocus
                                    required
                                />
                                <p className="text-[9px] text-slate-400 mt-1 ml-1">Nomor Urut</p>
                            </div>

                            {/* 3. YEAR CODE (AUTO) */}
                            <div className="w-16">
                                <div className="bg-emerald-100 border border-emerald-200 rounded-xl p-3 flex items-center justify-center h-[46px]">
                                    <span className="text-emerald-700 font-black text-lg">{woParts.year}</span>
                                </div>
                                <p className="text-[9px] text-emerald-600 mt-1 text-center font-bold">{new Date().getFullYear()}</p>
                            </div>
                        </div>
                        <div className="mt-2 text-right">
                             <span className="text-xs font-bold text-slate-400">Preview: </span>
                             <span className="text-sm font-black text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md">
                                 {formData.kodeBarang || '...'}
                             </span>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                             <label className={labelStyle}>Daya (KW)</label>
                             <div className={inputGroupStyle}>
                                <input type="number" step="0.01" name="dayaKW" value={formData.dayaKW} onChange={handleChange} placeholder="0.0" className={inputStyle} />
                             </div>
                        </div>
                         <div>
                             <label className={labelStyle}>Volt (V)</label>
                             <div className={inputGroupStyle}>
                                <input type="number" name="teganganVolt" value={formData.teganganVolt} onChange={handleChange} placeholder="380" className={inputStyle} />
                             </div>
                        </div>
                         <div>
                             <label className={labelStyle}>RPM</label>
                             <div className={inputGroupStyle}>
                                <input type="number" name="rpm" value={formData.rpm} onChange={handleChange} placeholder="1500" className={inputStyle} />
                             </div>
                        </div>
                         <div>
                             <label className={labelStyle}>Ampere (A)</label>
                             <div className={inputGroupStyle}>
                                <input type="number" step="0.1" name="arusAmpere" value={formData.arusAmpere} onChange={handleChange} placeholder="0.0" className={inputStyle} />
                             </div>
                        </div>
                    </div>

                    <div>
                        <label className={labelStyle}>Nama Perusahaan (Optional)</label>
                        <div className={inputGroupStyle}>
                             <input name="namaPerusahaan" value={formData.namaPerusahaan} onChange={handleChange} placeholder="PT. ..." className={inputStyle} />
                        </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                        <button type="button" onClick={onCancel} className="flex-1 py-3 rounded-xl font-bold text-slate-500 hover:bg-slate-100 transition-colors text-sm">Batal</button>
                        <button 
                            type="submit" 
                            disabled={isUploading}
                            className={`flex-[2] py-3 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/30 hover:bg-emerald-700 transition-all text-sm flex items-center justify-center gap-2 ${isUploading ? 'opacity-75 cursor-wait' : ''}`}
                        >
                            {isUploading ? 'Mengunggah ke Cloud...' : 'Simpan & Upload'}
                        </button>
                    </div>
                </form>
            </div>

            {/* RIGHT SIDE: PHOTO UPLOAD */}
            <div className="w-full md:w-[420px] bg-slate-50 border-l border-white/50 p-8 flex flex-col relative">
                <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                     <svg className="w-64 h-64 text-slate-300" fill="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                </div>

                <div className="relative z-10 h-full flex flex-col">
                    <h3 className="font-bold text-slate-800 text-lg mb-1">Dokumentasi Fisik</h3>
                    <p className="text-xs text-slate-500 mb-4">Wajib 4-10 foto. Tersimpan di Cloudinary.</p>

                    {/* Upload Box */}
                    <div 
                        onClick={() => fileInputRef.current?.click()}
                        className={`border-3 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center bg-white/50 hover:bg-emerald-50 ${
                            previewUrls.length < 4 ? 'border-red-300' : 'border-emerald-300'
                        }`}
                    >
                        <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handlePhotoSelect} />
                        <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center mb-2">
                             <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        </div>
                        <span className="text-sm font-bold text-slate-600">Klik Ambil / Pilih Foto</span>
                        <span className={`text-[10px] font-bold mt-1 ${previewUrls.length < 4 ? 'text-red-500' : 'text-emerald-500'}`}>
                            {previewUrls.length} / 10 Foto Terpilih
                        </span>
                    </div>

                    {/* Preview Grid */}
                    <div className="flex-1 overflow-y-auto mt-4 custom-scrollbar">
                        <div className="grid grid-cols-3 gap-2">
                             {previewUrls.map((url, idx) => (
                                 <motion.div initial={{opacity:0, scale:0.8}} animate={{opacity:1, scale:1}} key={idx} className="aspect-square relative group rounded-lg overflow-hidden border border-slate-200 shadow-sm">
                                     <img src={url} className="w-full h-full object-cover" alt="preview" />
                                     <button 
                                        type="button"
                                        onClick={() => removePhoto(idx)}
                                        className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                                     >
                                         <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                     </button>
                                     {idx === 0 && <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[8px] font-bold text-center py-0.5">COVER</div>}
                                 </motion.div>
                             ))}
                        </div>
                    </div>

                    {/* Footer Info */}
                    <div className="mt-4 bg-emerald-50 p-3 rounded-xl border border-emerald-100 flex gap-3 items-center">
                        <svg className="w-8 h-8 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        <div>
                            <p className="text-[10px] font-bold text-emerald-800">Auto Cloud Sync</p>
                            <p className="text-[9px] text-emerald-600 leading-tight">Foto otomatis diberi watermark logo & disimpan di folder WO.</p>
                        </div>
                    </div>
                </div>
            </div>
        </motion.div>
    </div>
  );
};