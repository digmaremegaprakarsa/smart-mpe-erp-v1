import React, { useState, useRef } from 'react';
import { MotorData, MotorStatus } from '../types';
import { motion } from 'framer-motion';
import { PhotoGalleryModal } from './PhotoGalleryModal';
import * as XLSX from 'xlsx';

interface MotorTableProps {
  data: MotorData[];
  onEdit: (motor: MotorData) => void;
  onView: (motor: MotorData) => void;
  onImport?: (data: MotorData[]) => void;
}

export const MotorTable: React.FC<MotorTableProps> = ({ data, onEdit, onView, onImport }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGalleryMotor, setSelectedGalleryMotor] = useState<MotorData | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredData = data.filter(item => 
    item.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.namaPerusahaan.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Helper to simulate Cloudinary Thumbnail Transformation for table view
  // w_50,h_50,c_thumb = Width 50px, Height 50px, Crop Thumbnail
  const getTableThumbnail = (url: string) => {
      if (!url) return '';
      if (url.includes('cloudinary.com')) {
          return url.replace("/upload/", "/upload/w_50,h_50,c_thumb,g_face/");
      }
      return url;
  };

  const handleDownloadTemplate = () => {
    const headers = [
      [
        "KODE BARANG", 
        "NAMA PERUSAHAAN", 
        "JENIS MOTOR", 
        "MERK", 
        "SERIAL NUMBER", 
        "KODE CUSTOMER", 
        "DAYA (KW)", 
        "TEGANGAN (VOLT)", 
        "FREKUENSI (HERTZ)", 
        "KECEPATAN MOTOR (RPM)", 
        "ARUS (AMPERE)", 
        "INFO CUSTOMER", 
        "TANGGAL MASUK", 
        "TANGGAL KIRIM", 
        "NO SURAT JALAN", 
        "STATUS FORM PUTIH", 
        "STATUS FORM BIRU", 
        "DATA MEGGER", 
        "NOMOR PENAWARAN", 
        "TANGGAL PENAWARAN", 
        "NOMOR PURCHASE ORDER", 
        "STATUS"
      ]
    ];
    const ws = XLSX.utils.aoa_to_sheet(headers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, "Template_Import_Motor_Lengkap.xlsx");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      
      // Convert sheet to JSON array of arrays (header: 1)
      const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];

      // Remove header row (index 0)
      const rows = data.slice(1);
      
      // Map Excel Rows to MotorData Interface
      const newMotors: MotorData[] = rows
        .filter(row => row[0]) // Ensure 'KODE BARANG' exists
        .map((row) => {
            // Helper to clean status
            const cleanStatus = (val: any): string => {
                const s = String(val || '').toUpperCase().trim();
                return (s === 'SUDAH' || s === 'YES' || s === 'TRUE') ? 'SUDAH' : 'BELUM';
            };

            // Helper to clean Motor Status
            const cleanMotorStatus = (val: any): MotorStatus => {
                const s = String(val || '').toUpperCase().trim();
                if (s === 'KIRIM') return MotorStatus.KIRIM;
                if (s === 'PENDING') return MotorStatus.PENDING;
                if (s === 'CANCEL') return MotorStatus.CANCEL;
                return MotorStatus.ON_PROGRESS;
            };

            return {
                // 0 - 5: Identity
                kodeBarang: String(row[0]).trim(),
                namaPerusahaan: row[1] ? String(row[1]).toUpperCase().trim() : '',
                jenisMotor: row[2] ? String(row[2]).toUpperCase().trim() : 'AC MOTOR',
                merk: row[3] ? String(row[3]).toUpperCase().trim() : '',
                serialNumber: row[4] ? String(row[4]).trim() : '-',
                kodeCustomer: row[5] ? String(row[5]).trim() : '',
                
                // 6 - 10: Technical Specs (Convert to Numbers)
                dayaKW: row[6] ? Number(row[6]) : 0,
                teganganVolt: row[7] ? Number(row[7]) : 0,
                frekuensiHz: row[8] ? Number(row[8]) : 50,
                rpm: row[9] ? Number(row[9]) : 0,
                arusAmpere: row[10] ? Number(row[10]) : 0,
                
                // 11 - 14: Info & Tracking
                infoCustomer: row[11] ? String(row[11]).trim() : '',
                tanggalMasuk: row[12] ? String(row[12]).trim() : new Date().toISOString().split('T')[0],
                tanggalKirim: row[13] ? String(row[13]).trim() : '',
                noSuratJalan: row[14] ? String(row[14]).trim() : '',
                
                // 15 - 17: Workshop Checklist
                statusFormPutih: cleanStatus(row[15]) as 'SUDAH' | 'BELUM',
                statusFormBiru: cleanStatus(row[16]) as 'SUDAH' | 'BELUM',
                dataMegger: cleanStatus(row[17]) as 'SUDAH' | 'BELUM',
                
                // 18 - 20: Admin Commercial
                nomorPenawaran: row[18] ? String(row[18]).trim() : '',
                tanggalPenawaran: row[19] ? String(row[19]).trim() : '',
                nomorPO: row[20] ? String(row[20]).trim() : '',
                
                // 21: Final Status
                status: cleanMotorStatus(row[21]),
                
                // Defaults (Not in Excel)
                dokumentasiUrl: '',
                fotoUrls: []
            };
      });

      if (onImport && newMotors.length > 0) {
        onImport(newMotors);
      } else {
        alert("Tidak ada data valid yang ditemukan dalam file Excel.");
      }
      
      // Reset input to allow re-uploading same file if needed
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.onerror = (err) => {
        console.error("Error reading file:", err);
        alert("Gagal membaca file Excel.");
    };

    reader.readAsBinaryString(file);
  };

  return (
    <>
        <div className="glass rounded-[2rem] flex flex-col h-[calc(100vh-180px)] md:h-[calc(100vh-140px)] overflow-hidden shadow-xl">
        {/* Toolbar */}
        <div className="p-6 border-b border-white/40 flex flex-col md:flex-row gap-4 justify-between items-center bg-white/30 backdrop-blur-sm">
            <div className="w-full md:w-auto">
            <div className="relative">
                <span className="absolute left-4 top-3.5 text-slate-400">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                </span>
                <input
                    type="text"
                    placeholder="Search Order ID or Company..."
                    className="w-full md:w-80 pl-12 pr-4 py-3 border-none bg-white/60 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-400 outline-none text-slate-700 shadow-sm transition-all hover:bg-white/80"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            </div>
            
            <div className="flex gap-3 w-full md:w-auto">
                <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileUpload} 
                    accept=".xlsx, .xls" 
                    className="hidden" 
                />
                {onImport && (
                    <>
                        <motion.button 
                            whileHover={{ scale: 1.05 }} 
                            onClick={handleDownloadTemplate}
                            className="flex-1 md:flex-none px-4 py-3 bg-emerald-50/50 hover:bg-emerald-100 text-emerald-600 rounded-2xl text-xs font-bold transition-colors shadow-sm flex items-center gap-1"
                            title="Download Excel Template"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                            Template
                        </motion.button>
                        <motion.button 
                            whileHover={{ scale: 1.05 }} 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex-1 md:flex-none px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-sm font-bold transition-colors shadow-sm flex items-center gap-2"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                            Import
                        </motion.button>
                    </>
                )}
                <motion.button whileHover={{ scale: 1.05 }} className="flex-1 md:flex-none px-6 py-3 bg-white/50 hover:bg-white text-slate-600 rounded-2xl text-sm font-bold transition-colors shadow-sm">
                    Filter
                </motion.button>
                <motion.button whileHover={{ scale: 1.05 }} className="flex-1 md:flex-none px-6 py-3 bg-indigo-50/50 hover:bg-indigo-100 text-indigo-600 rounded-2xl text-sm font-bold transition-colors shadow-sm" onClick={() => window.print()}>
                    Export
                </motion.button>
            </div>
        </div>

        {/* Table Container */}
        <div className="overflow-auto flex-1 w-full relative">
            <table className="w-full min-w-[2600px] text-sm text-left border-separate border-spacing-y-2 px-4">
            <thead className="text-slate-500 font-extrabold uppercase text-[11px] tracking-wider sticky top-0 z-20">
                <tr>
                <th className="p-4 pl-6 bg-slate-100/90 backdrop-blur-md first:rounded-l-2xl shadow-sm whitespace-nowrap sticky left-0 z-30 border-r border-slate-200">Action</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Dokumentasi</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Kode Barang</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Nama Perusahaan</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Jenis Motor</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Merk</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Serial Number</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Kode Customer</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Daya (KW)</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Tegangan (Volt)</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Frekuensi (Hz)</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">RPM</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Arus (Ampere)</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50 w-64">Info Customer</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Tanggal Masuk</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Tanggal Kirim</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">No Surat Jalan</th>
                {/* NEW COLUMNS */}
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Form Putih</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Form Biru</th>
                <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap border-r border-slate-200/50">Megger</th>
                
                <th className="p-4 bg-slate-50/90 backdrop-blur-md last:rounded-r-2xl shadow-sm whitespace-nowrap">Status</th>
                </tr>
            </thead>
            <tbody className="pb-4">
                {filteredData.map((row, index) => (
                <motion.tr 
                    key={row.kodeBarang}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white/40 hover:bg-white/80 transition-colors group shadow-sm rounded-2xl cursor-default"
                >
                    <td className="p-3 pl-6 rounded-l-2xl border-y border-l border-white/40 group-hover:border-white whitespace-nowrap sticky left-0 bg-white/40 backdrop-blur-sm z-10 shadow-[4px_0_10px_-2px_rgba(0,0,0,0.05)]">
                    <div className="flex gap-2">
                        <motion.button 
                            whileTap={{ scale: 0.9 }}
                            onClick={() => onView(row)}
                            className="bg-slate-100 text-slate-600 p-2 rounded-xl hover:bg-slate-800 hover:text-white transition-all shadow-sm"
                            title="View Detail"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                        </motion.button>
                        <motion.button 
                            whileTap={{ scale: 0.9 }}
                            onClick={() => onEdit(row)}
                            className="bg-indigo-100 text-indigo-600 p-2 rounded-xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                            title="Edit Job"
                        >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                        </motion.button>
                    </div>
                    </td>
                    <td className="p-2 border-y border-white/40 group-hover:border-white whitespace-nowrap">
                        {/* Gallery Trigger with Cloudinary Thumb Simulation */}
                        <div 
                            className="relative w-12 h-12 rounded-lg bg-slate-200 overflow-hidden cursor-pointer hover:ring-2 hover:ring-indigo-400 transition-all border border-white"
                            onClick={() => {
                                if (row.fotoUrls && row.fotoUrls.length > 0) {
                                    setSelectedGalleryMotor(row);
                                }
                            }}
                            title={row.fotoUrls && row.fotoUrls.length > 0 ? `View ${row.fotoUrls.length} photos` : "No photos"}
                        >
                            {row.fotoUrls && row.fotoUrls.length > 0 ? (
                                <>
                                    <img src={getTableThumbnail(row.fotoUrls[0])} alt="thumbnail" className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 bg-black/10 hover:bg-black/0 transition-colors"></div>
                                    <div className="absolute bottom-0 right-0 bg-black/60 text-white text-[8px] px-1 font-bold rounded-tl-md">
                                        {row.fotoUrls.length}
                                    </div>
                                </>
                            ) : (
                                <div className="w-full h-full flex items-center justify-center text-slate-400">
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                </div>
                            )}
                        </div>
                    </td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white font-black text-slate-700 whitespace-nowrap">{row.kodeBarang}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-bold whitespace-nowrap">{row.namaPerusahaan}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-500 font-medium whitespace-nowrap">{row.jenisMotor}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-500 font-medium whitespace-nowrap uppercase">{row.merk || '-'}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-500 font-medium whitespace-nowrap font-mono">{row.serialNumber || '-'}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-500 font-medium whitespace-nowrap">{row.kodeCustomer || '-'}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-mono whitespace-nowrap">{row.dayaKW}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-mono whitespace-nowrap">{row.teganganVolt}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-mono whitespace-nowrap">{row.frekuensiHz}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-mono whitespace-nowrap">{row.rpm}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 font-mono whitespace-nowrap">{row.arusAmpere}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 text-xs font-medium max-w-xs truncate">{row.infoCustomer}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 whitespace-nowrap font-medium">{row.tanggalMasuk}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 whitespace-nowrap font-medium">{row.tanggalKirim || '-'}</td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white text-slate-600 whitespace-nowrap font-medium">{row.noSuratJalan || '-'}</td>
                    
                    {/* NEW STATUS COLUMNS */}
                    <td className="p-3 border-y border-white/40 group-hover:border-white whitespace-nowrap">
                        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg w-fit ${row.statusFormPutih === 'SUDAH' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                            <div className={`w-2 h-2 rounded-full ${row.statusFormPutih === 'SUDAH' ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                            <span className="text-[10px] font-bold">{row.statusFormPutih}</span>
                        </div>
                    </td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white whitespace-nowrap">
                        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg w-fit ${row.statusFormBiru === 'SUDAH' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                            <div className={`w-2 h-2 rounded-full ${row.statusFormBiru === 'SUDAH' ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                            <span className="text-[10px] font-bold">{row.statusFormBiru}</span>
                        </div>
                    </td>
                    <td className="p-3 border-y border-white/40 group-hover:border-white whitespace-nowrap">
                        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg w-fit ${row.dataMegger === 'SUDAH' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                            <div className={`w-2 h-2 rounded-full ${row.dataMegger === 'SUDAH' ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                            <span className="text-[10px] font-bold">{row.dataMegger}</span>
                        </div>
                    </td>

                    <td className="p-3 rounded-r-2xl border-y border-r border-white/40 group-hover:border-white whitespace-nowrap">
                        <span className={`px-4 py-1.5 rounded-xl text-[10px] font-extrabold uppercase tracking-wide shadow-sm ${
                            row.status === MotorStatus.KIRIM ? 'bg-emerald-100 text-emerald-600' :
                            row.status === MotorStatus.ON_PROGRESS ? 'bg-amber-100 text-amber-600' :
                            'bg-slate-100 text-slate-500'
                        }`}>
                            {row.status}
                        </span>
                    </td>
                </motion.tr>
                ))}
            </tbody>
            </table>
            {filteredData.length === 0 && (
                <div className="text-center py-20">
                    <p className="text-slate-400 font-medium">No records found matching your search.</p>
                </div>
            )}
        </div>
        </div>

        {/* Gallery Modal */}
        {selectedGalleryMotor && (
            <PhotoGalleryModal 
                isOpen={!!selectedGalleryMotor} 
                onClose={() => setSelectedGalleryMotor(null)}
                imageUrls={selectedGalleryMotor.fotoUrls || []}
                title={selectedGalleryMotor.kodeBarang}
            />
        )}
    </>
  );
};