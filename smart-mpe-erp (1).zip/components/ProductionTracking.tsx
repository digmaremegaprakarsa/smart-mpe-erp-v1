
import React, { useState, useEffect } from 'react';
import { MotorData, ProductionWO, TrackingMatrix, UserRole, ProductionLog } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import * as XLSX from 'xlsx';

interface ProductionTrackingProps {
    motors: MotorData[];
    productionData: ProductionWO[];
    onUpdateProduction: (data: ProductionWO) => void;
    currentUserRole: UserRole;
}

const emptyMatrix: TrackingMatrix = {
    rew_stator: false, rew_rotor: false, ovh_stator: false, ovh_rotor: false, 
    dismantling: false, cleaning: false, varnish: false, assembling: false, painting: false,
    reb_de: false, reb_nde: false, js_de: false, js_nde: false,
    bal_rotor: false, part: false, qc: false, finishing: false
};

export const ProductionTracking: React.FC<ProductionTrackingProps> = ({ motors, productionData, onUpdateProduction, currentUserRole }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedWO, setSelectedWO] = useState<ProductionWO | null>(null);
    const [filterScope, setFilterScope] = useState<string>('ALL');
    const [isEditing, setIsEditing] = useState(false);

    // Form Local State
    const [formData, setFormData] = useState<{
        tanggalMasuk: string,
        tanggalKirim: string,
        nomorPO: string
    }>({ tanggalMasuk: '', tanggalKirim: '', nomorPO: '' });

    // Merge Data for View
    const combinedData = productionData.map(prod => {
        const motor = motors.find(m => m.kodeBarang === prod.kodeBarang);
        return {
            ...prod,
            motorName: motor?.namaPerusahaan || 'Unknown',
            motorType: motor?.jenisMotor || '-',
            motorKW: motor?.dayaKW || 0,
            motorRPM: motor?.rpm || 0,
            tanggalMasuk: motor?.tanggalMasuk || '-',
            tanggalKirim: motor?.tanggalKirim || '-',
            nomorPO: motor?.nomorPO || '-'
        };
    }).filter(item => {
        const matchesSearch = item.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              item.motorName.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesScope = filterScope === 'ALL' || item.scope === filterScope;
        return matchesSearch && matchesScope;
    });

    const calculateProgress = (scope: TrackingMatrix, progress: TrackingMatrix) => {
        const keys = Object.keys(scope) as (keyof TrackingMatrix)[];
        const requiredTasks = keys.filter(k => scope[k]);
        if (requiredTasks.length === 0) return 0;
        
        const completedTasks = requiredTasks.filter(k => progress[k]).length;
        return Math.round((completedTasks / requiredTasks.length) * 100);
    };

    const handleExportExcel = () => {
        const ws = XLSX.utils.json_to_sheet(combinedData.map(d => ({
            WO: d.kodeBarang,
            Customer: d.motorName,
            Scope: d.scope,
            Progress: `${calculateProgress(d.jobScope || emptyMatrix, d.progress)}%`,
            Status: d.progress.finishing ? 'DONE' : 'WIP'
        })));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Backlog");
        XLSX.writeFile(wb, "Production_Backlog.xlsx");
    };

    const handleCreateNew = () => {
        const newWO: ProductionWO = {
            kodeBarang: '', // Will be selected
            scope: 'OVH',
            priority: 'Normal',
            machiningNotes: '',
            keterangan: '',
            jobScope: emptyMatrix, // Initial Scope
            progress: emptyMatrix, // Initial Progress
            logs: []
        };
        setSelectedWO(newWO);
        setIsEditing(true);
        setFormData({ tanggalMasuk: '', tanggalKirim: '', nomorPO: '' });
    };

    const handleSelectWO = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const woId = e.target.value;
        const motor = motors.find(m => m.kodeBarang === woId);
        
        // Use existing production data if available
        const existingProd = productionData.find(p => p.kodeBarang === woId);
        
        if (existingProd) {
            setSelectedWO(existingProd);
            setFormData({
                tanggalMasuk: motor?.tanggalMasuk || '',
                tanggalKirim: motor?.tanggalKirim || '',
                nomorPO: motor?.nomorPO || ''
            });
        } else {
            // Initialize new production entry linked to this motor
            setSelectedWO(prev => prev ? ({ 
                ...prev, 
                kodeBarang: woId,
                jobScope: emptyMatrix,
                progress: emptyMatrix 
            }) : null);
            setFormData({
                tanggalMasuk: motor?.tanggalMasuk || '',
                tanggalKirim: motor?.tanggalKirim || '',
                nomorPO: motor?.nomorPO || ''
            });
        }
    };

    // Note: In the Input Modal, we are toggling SCOPE (Planning), not Progress.
    const handleScopeToggle = (key: keyof TrackingMatrix) => {
        if (!selectedWO) return;
        
        // Safety check for jobScope existence
        const currentScope = selectedWO.jobScope || emptyMatrix;
        
        const updatedScope = { ...currentScope, [key]: !currentScope[key] };
        
        const updatedWO = {
            ...selectedWO,
            jobScope: updatedScope
        };

        setSelectedWO(updatedWO);
        // We don't necessarily need to log planning changes as strictly as execution changes, but we can.
    };

    // Components for Modal
    const ToggleButton = ({ label, value, onClick }: { label: string, value: boolean, onClick: () => void }) => (
        <button
            onClick={onClick}
            className={`w-full p-2.5 rounded-lg border flex items-center justify-between transition-all text-xs font-bold ${
                value 
                ? 'bg-emerald-500 border-emerald-600 text-white' 
                : 'bg-white border-slate-200 text-slate-500 hover:border-indigo-300'
            }`}
        >
            <span>{label}</span>
            {value && <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
        </button>
    );

    const linkedMotor = motors.find(m => m.kodeBarang === selectedWO?.kodeBarang);

    return (
        <div className="flex flex-col h-full gap-6 pb-20">
            {/* Toolbar */}
            <div className="glass p-4 rounded-2xl flex justify-between items-center shadow-sm">
                <div className="flex items-center gap-3">
                    <h2 className="text-xl font-bold text-slate-800">Production Backlog</h2>
                    <span className="bg-slate-200 text-slate-600 px-2 py-1 rounded text-xs font-bold">{combinedData.length} Items</span>
                </div>
                <div className="flex gap-2">
                    <button onClick={handleCreateNew} className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md hover:bg-indigo-700 transition-colors flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                        Input Production
                    </button>
                    <button onClick={handleExportExcel} className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md hover:bg-emerald-700 transition-colors">
                        Export Excel
                    </button>
                </div>
            </div>

            {/* Main Table */}
            <div className="glass rounded-[2rem] flex-1 overflow-hidden shadow-xl border border-white/50 relative">
                <div className="absolute top-4 right-4 z-10">
                    <input 
                        type="text" 
                        placeholder="Search..." 
                        className="bg-white/80 border-none rounded-xl py-2 px-4 text-xs font-bold shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none w-64"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="overflow-auto h-full p-4">
                    <table className="w-full text-sm text-left border-separate border-spacing-y-2">
                        <thead className="text-slate-500 font-extrabold uppercase text-[10px] tracking-wider sticky top-0 z-10">
                            <tr>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md first:rounded-l-xl">WO No.</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md">Customer</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md">Scope</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md">Dates (SPK / Del)</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md">PO No.</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md text-center">Progress</th>
                                <th className="p-4 bg-slate-100/90 backdrop-blur-md last:rounded-r-xl text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {combinedData.map((item, idx) => {
                                const progress = calculateProgress(item.jobScope || emptyMatrix, item.progress);
                                return (
                                    <motion.tr 
                                        key={item.kodeBarang || idx}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        onClick={() => { setSelectedWO(item); setIsEditing(true); setFormData({ tanggalMasuk: item.tanggalMasuk, tanggalKirim: item.tanggalKirim, nomorPO: item.nomorPO }); }}
                                        className="bg-white hover:bg-indigo-50 cursor-pointer transition-colors group rounded-xl shadow-sm"
                                    >
                                        <td className="p-4 font-black text-indigo-900 rounded-l-xl">{item.kodeBarang}</td>
                                        <td className="p-4 font-bold text-slate-700">
                                            {item.motorName}
                                            <div className="text-[10px] text-slate-400 font-normal">{item.motorKW} KW - {item.motorRPM} RPM</div>
                                        </td>
                                        <td className="p-4"><span className="bg-slate-100 px-2 py-1 rounded text-[10px] font-bold">{item.scope}</span></td>
                                        <td className="p-4 text-xs font-mono text-slate-600">
                                            <div>In: {item.tanggalMasuk}</div>
                                            <div className="text-red-500">Out: {item.tanggalKirim}</div>
                                        </td>
                                        <td className="p-4 text-xs font-bold text-emerald-600">{item.nomorPO}</td>
                                        <td className="p-4 align-middle">
                                            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                                                <div className={`h-full rounded-full ${progress === 100 ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${progress}%` }}></div>
                                            </div>
                                        </td>
                                        <td className="p-4 rounded-r-xl text-center">
                                            {item.progress.finishing ? <span className="text-emerald-500 font-bold text-xs">DONE</span> : <span className="text-amber-500 font-bold text-xs">WIP</span>}
                                        </td>
                                    </motion.tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* INPUT / DETAIL MODULE MODAL */}
            <AnimatePresence>
                {selectedWO && isEditing && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
                        onClick={() => setIsEditing(false)}
                    >
                        <motion.div 
                            initial={{ scale: 0.95, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            exit={{ scale: 0.95, y: 20 }}
                            className="bg-white rounded-3xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200"
                            onClick={(e) => e.stopPropagation()}
                        >
                            {/* Header */}
                            <div className="bg-slate-50 p-6 border-b border-slate-200 flex justify-between items-center">
                                <div>
                                    <h2 className="text-xl font-black text-slate-800">Input Pekerjaan Produksi</h2>
                                    <p className="text-xs text-slate-500">Production Work Order Entry</p>
                                </div>
                                <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-slate-600">
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                </button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                                <div className="flex flex-col gap-8">
                                    
                                    {/* 1. WO Selection & Data */}
                                    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                                        <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">Data Motor (WO)</h3>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                            <div>
                                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Pilih Nomor WO</label>
                                                <select 
                                                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-indigo-500"
                                                    value={selectedWO.kodeBarang}
                                                    onChange={handleSelectWO}
                                                >
                                                    <option value="">-- Pilih WO --</option>
                                                    {motors.map(m => (
                                                        <option key={m.kodeBarang} value={m.kodeBarang}>{m.kodeBarang} - {m.namaPerusahaan}</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div>
                                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Customer</label>
                                                <input disabled value={linkedMotor?.namaPerusahaan || ''} className="w-full bg-slate-100 border-none rounded-lg px-3 py-2 text-sm font-bold text-slate-500" />
                                            </div>
                                        </div>
                                        {linkedMotor && (
                                            <div className="grid grid-cols-4 gap-2 text-xs">
                                                <div className="bg-slate-50 p-2 rounded">
                                                    <span className="block text-[9px] text-slate-400 font-bold uppercase">KW</span>
                                                    <span className="font-bold">{linkedMotor.dayaKW}</span>
                                                </div>
                                                <div className="bg-slate-50 p-2 rounded">
                                                    <span className="block text-[9px] text-slate-400 font-bold uppercase">RPM</span>
                                                    <span className="font-bold">{linkedMotor.rpm}</span>
                                                </div>
                                                <div className="bg-slate-50 p-2 rounded">
                                                    <span className="block text-[9px] text-slate-400 font-bold uppercase">Volt</span>
                                                    <span className="font-bold">{linkedMotor.teganganVolt}</span>
                                                </div>
                                                <div className="bg-slate-50 p-2 rounded">
                                                    <span className="block text-[9px] text-slate-400 font-bold uppercase">Amp</span>
                                                    <span className="font-bold">{linkedMotor.arusAmpere}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    {/* 2. Admin Inputs */}
                                    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                                        <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">Administrasi Produksi</h3>
                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <div>
                                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tanggal SPK (Masuk)</label>
                                                <input type="date" value={formData.tanggalMasuk} onChange={(e) => setFormData({...formData, tanggalMasuk: e.target.value})} className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500" />
                                            </div>
                                            <div>
                                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Target Kirim</label>
                                                <input type="date" value={formData.tanggalKirim} onChange={(e) => setFormData({...formData, tanggalKirim: e.target.value})} className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500" />
                                            </div>
                                            <div>
                                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Nomor PO</label>
                                                <input type="text" value={formData.nomorPO} onChange={(e) => setFormData({...formData, nomorPO: e.target.value})} placeholder="No. PO Customer" className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500" />
                                            </div>
                                        </div>
                                    </div>

                                    {/* 3. Job Scope & Matrix */}
                                    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                                        <div className="flex justify-between items-center mb-4 border-b pb-2">
                                            <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest">Scope & Checklist Pekerjaan</h3>
                                            <span className="text-[10px] text-indigo-500 font-bold bg-indigo-50 px-2 py-1 rounded">Centang untuk Aktifkan di Job Card</span>
                                        </div>
                                        
                                        <div className="mb-6">
                                            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Scope Utama</label>
                                            <div className="flex gap-2">
                                                {['REW', 'OVH', 'MEC', 'NEW'].map(sc => (
                                                    <button 
                                                        key={sc}
                                                        onClick={() => onUpdateProduction({...selectedWO, scope: sc as any})}
                                                        className={`px-4 py-2 rounded-lg text-xs font-bold border transition-colors ${selectedWO.scope === sc ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-200'}`}
                                                    >
                                                        {sc}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                            {/* Electrical */}
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black text-indigo-900 uppercase mb-2">Electrical / Winding</h4>
                                                {/* Use jobScope here, defaulting to emptyMatrix if undefined */}
                                                <ToggleButton label="Rewinding Stator" value={(selectedWO.jobScope || emptyMatrix).rew_stator} onClick={() => handleScopeToggle('rew_stator')} />
                                                <ToggleButton label="Rewinding Rotor" value={(selectedWO.jobScope || emptyMatrix).rew_rotor} onClick={() => handleScopeToggle('rew_rotor')} />
                                                <ToggleButton label="Overhaul Stator" value={(selectedWO.jobScope || emptyMatrix).ovh_stator} onClick={() => handleScopeToggle('ovh_stator')} />
                                                <ToggleButton label="Overhaul Rotor" value={(selectedWO.jobScope || emptyMatrix).ovh_rotor} onClick={() => handleScopeToggle('ovh_rotor')} />
                                            </div>

                                            {/* Mechanical */}
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black text-blue-900 uppercase mb-2">Mechanical</h4>
                                                <ToggleButton label="Dismantling" value={(selectedWO.jobScope || emptyMatrix).dismantling} onClick={() => handleScopeToggle('dismantling')} />
                                                <ToggleButton label="Cleaning" value={(selectedWO.jobScope || emptyMatrix).cleaning} onClick={() => handleScopeToggle('cleaning')} />
                                                <ToggleButton label="Varnish" value={(selectedWO.jobScope || emptyMatrix).varnish} onClick={() => handleScopeToggle('varnish')} />
                                                <ToggleButton label="Assembling" value={(selectedWO.jobScope || emptyMatrix).assembling} onClick={() => handleScopeToggle('assembling')} />
                                                <ToggleButton label="Painting" value={(selectedWO.jobScope || emptyMatrix).painting} onClick={() => handleScopeToggle('painting')} />
                                                <ToggleButton label="Part Replacement" value={(selectedWO.jobScope || emptyMatrix).part} onClick={() => handleScopeToggle('part')} />
                                            </div>

                                            {/* Machining */}
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black text-amber-900 uppercase mb-2">Machining</h4>
                                                <ToggleButton label="Rebushing DE" value={(selectedWO.jobScope || emptyMatrix).reb_de} onClick={() => handleScopeToggle('reb_de')} />
                                                <ToggleButton label="Rebushing NDE" value={(selectedWO.jobScope || emptyMatrix).reb_nde} onClick={() => handleScopeToggle('reb_nde')} />
                                                <ToggleButton label="Journal Shaft DE" value={(selectedWO.jobScope || emptyMatrix).js_de} onClick={() => handleScopeToggle('js_de')} />
                                                <ToggleButton label="Journal Shaft NDE" value={(selectedWO.jobScope || emptyMatrix).js_nde} onClick={() => handleScopeToggle('js_nde')} />
                                                <ToggleButton label="Balancing Rotor" value={(selectedWO.jobScope || emptyMatrix).bal_rotor} onClick={() => handleScopeToggle('bal_rotor')} />
                                            </div>

                                            {/* QC */}
                                            <div className="space-y-2">
                                                <h4 className="text-xs font-black text-emerald-900 uppercase mb-2">Finishing & QC</h4>
                                                <ToggleButton label="QC Check" value={(selectedWO.jobScope || emptyMatrix).qc} onClick={() => handleScopeToggle('qc')} />
                                                <ToggleButton label="Finishing / Paint" value={(selectedWO.jobScope || emptyMatrix).finishing} onClick={() => handleScopeToggle('finishing')} />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div className="p-6 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                                <button onClick={() => setIsEditing(false)} className="px-6 py-3 rounded-xl font-bold text-slate-500 hover:bg-slate-200 transition-colors text-sm">Cancel</button>
                                <button 
                                    onClick={() => {
                                        onUpdateProduction(selectedWO); 
                                        setIsEditing(false);
                                        alert("Data Production Saved!");
                                    }} 
                                    className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-transform hover:scale-105 text-sm"
                                >
                                    Save Entry
                                </button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};