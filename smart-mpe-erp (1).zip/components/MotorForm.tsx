import React, { useState, useEffect, useRef } from 'react';
import { MotorData, MotorStatus, UserRole } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface MotorFormProps {
  initialData?: MotorData | null;
  onSave: (data: MotorData) => void;
  onCancel: () => void;
  userRole: UserRole;
}

const emptyMotor: MotorData = {
  kodeBarang: '',
  namaPerusahaan: '',
  kodeCustomer: '',
  jenisMotor: '',
  merk: '',
  serialNumber: '',
  dayaKW: '',
  teganganVolt: '',
  frekuensiHz: '',
  rpm: '',
  arusAmpere: '',
  statusFormPutih: 'BELUM',
  statusFormBiru: 'BELUM',
  dataMegger: 'BELUM',
  infoCustomer: '',
  status: MotorStatus.ON_PROGRESS,
  dokumentasiUrl: '',
  fotoUrls: [],
  tanggalMasuk: new Date().toISOString().split('T')[0],
  tanggalKirim: '',
  noSuratJalan: '',
  nomorPenawaran: '',
  tanggalPenawaran: '',
  nomorPO: ''
};

const COMPLAINT_OPTIONS = ['OVERHAUL', 'REWINDING', 'REPAIR'];

const SALES_CODES = [
    { code: 'P', label: 'P - Pusat' },
    { code: 'I', label: 'I - Ine' },
    { code: 'H', label: 'H - Hendar' },
    { code: 'R', label: 'R - Rully' }
];

const YEAR_CODES: { [key: number]: string } = {
    2024: 'J',
    2025: 'K',
    2026: 'L',
    2027: 'M',
    2028: 'N',
    2029: 'O',
    2030: 'P'
};

export const MotorForm: React.FC<MotorFormProps> = ({ initialData, onSave, onCancel, userRole }) => {
  const [formData, setFormData] = useState<MotorData>(initialData || emptyMotor);
  const [complaintType, setComplaintType] = useState<string>('');

  // Photo Upload State
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // WO Configuration State (Only for New Data)
  const [woConfig, setWoConfig] = useState({
      sales: 'P',
      sequence: '',
      yearCode: 'K' // Default
  });

  // --- 1. Init Data & Complaint Type ---
  useEffect(() => {
    if (initialData) {
        setFormData(initialData);
        // Load existing photos into preview
        if (initialData.fotoUrls && initialData.fotoUrls.length > 0) {
            setPreviewUrls(initialData.fotoUrls);
        } else if (initialData.dokumentasiUrl) {
            setPreviewUrls([initialData.dokumentasiUrl]);
        }

        if (COMPLAINT_OPTIONS.includes(initialData.infoCustomer)) {
            setComplaintType(initialData.infoCustomer);
        } else if (initialData.infoCustomer) {
            setComplaintType('LAINNYA');
        } else {
            setComplaintType('');
        }
    } else {
        setFormData(emptyMotor);
        setComplaintType('');
        setPreviewUrls([]);
        
        // Auto-set Year Code for new entries
        const currentYear = new Date().getFullYear();
        const code = YEAR_CODES[currentYear] || '?';
        setWoConfig(prev => ({ ...prev, yearCode: code }));
    }
  }, [initialData]);

  // --- 2. Auto-Generate Kode Barang (WO ID) for New Entries ---
  useEffect(() => {
      if (!initialData) {
          // Format: [Sales][Sequence][YearCode] -> ex: P1024K
          const generatedID = `${woConfig.sales}${woConfig.sequence}${woConfig.yearCode}`;
          setFormData(prev => ({ ...prev, kodeBarang: generatedID }));
      }
  }, [woConfig, initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleWoConfigChange = (field: 'sales' | 'sequence', value: string) => {
      setWoConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleComplaintTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const val = e.target.value;
      setComplaintType(val);
      
      if (val !== 'LAINNYA') {
          setFormData(prev => ({ ...prev, infoCustomer: val }));
      } else {
          if (COMPLAINT_OPTIONS.includes(formData.infoCustomer)) {
              setFormData(prev => ({ ...prev, infoCustomer: '' }));
          }
      }
  };

  // --- PHOTO HANDLING ---
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
        const filesArray = Array.from(e.target.files);
        
        if (previewUrls.length + filesArray.length > 10) {
            alert("⚠️ Maksimal 10 foto yang diperbolehkan.");
            return;
        }
        
        // Create previews
        const newPreviews = filesArray.map((file) => URL.createObjectURL(file as Blob));
        const updatedPreviews = [...previewUrls, ...newPreviews];
        
        setPreviewUrls(updatedPreviews);
        
        // Update Form Data
        setFormData(prev => ({
            ...prev,
            fotoUrls: updatedPreviews,
            dokumentasiUrl: updatedPreviews[0] || '' // Set first image as main cover
        }));
    }
  };

  const removePhoto = (index: number) => {
      const updatedPreviews = previewUrls.filter((_, i) => i !== index);
      setPreviewUrls(updatedPreviews);
      setFormData(prev => ({
          ...prev,
          fotoUrls: updatedPreviews,
          dokumentasiUrl: updatedPreviews[0] || ''
      }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedData = { ...formData };
    
    // Validation for New Entry
    if (!initialData && !woConfig.sequence) {
        alert("Nomor Urut WO wajib diisi!");
        return;
    }

    if (updatedData.noSuratJalan && updatedData.status !== MotorStatus.KIRIM) {
        updatedData.status = MotorStatus.KIRIM;
    }
    onSave(updatedData);
  };

  // Logic for Progress Stepper
  const getProgressStep = () => {
      if (formData.status === MotorStatus.KIRIM) return 5; // Delivered
      if (formData.nomorPO) return 4; // Admin/Commercial Cleared
      if (formData.statusFormBiru === 'SUDAH') return 3; // Repair/QC Done
      if (formData.infoCustomer) return 2; // Diagnosis Done
      return 1; // Incoming
  };
  const currentStep = getProgressStep();

  const isAdminOrDev = userRole === UserRole.ADMIN || userRole === UserRole.DEVELOPER;
  const isTeknisi = userRole === UserRole.TEKNISI || userRole === UserRole.DEVELOPER;

  // Reusable styles
  const labelStyle = "block text-[10px] font-extrabold text-indigo-900/50 uppercase tracking-widest mb-1.5 ml-1";
  const inputContainerStyle = "bg-white/50 backdrop-blur-sm border border-white/50 rounded-2xl p-1 focus-within:ring-2 focus-within:ring-indigo-400 focus-within:bg-white transition-all shadow-sm";
  const inputStyle = "w-full bg-transparent border-none text-slate-800 font-bold placeholder-slate-300 focus:ring-0 outline-none p-3 text-sm";
  const sectionTitleStyle = "text-lg font-bold text-slate-900 mb-4 flex items-center gap-3 border-b border-slate-200/50 pb-2";
  const numberBadgeStyle = "w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center text-sm font-bold shadow-lg shadow-indigo-500/30";

  return (
    <div className="flex justify-center pb-10 h-full">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass rounded-[2.5rem] shadow-2xl border border-white/50 overflow-hidden w-full max-w-[95%] xl:max-w-7xl flex flex-col h-full md:h-auto"
        >
            {/* Visual Progress Stepper (New Blueprint Feature) */}
            <div className="bg-white/60 backdrop-blur-md px-6 py-4 border-b border-white/50">
                <div className="flex items-center justify-between relative">
                    <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-200 -z-10 rounded-full"></div>
                    <div className="absolute top-1/2 left-0 h-1 bg-emerald-500 -z-10 rounded-full transition-all duration-500" style={{ width: `${((currentStep - 1) / 4) * 100}%` }}></div>
                    
                    {['Incoming', 'Diagnosis', 'Repair', 'Admin', 'Delivery'].map((step, idx) => {
                        const stepNum = idx + 1;
                        const isActive = currentStep >= stepNum;
                        const isCurrent = currentStep === stepNum;
                        return (
                            <div key={step} className="flex flex-col items-center gap-2 group">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-4 transition-all duration-300 ${
                                    isActive ? 'bg-emerald-500 border-emerald-100 text-white scale-110 shadow-lg shadow-emerald-500/30' : 'bg-slate-100 border-slate-50 text-slate-400'
                                }`}>
                                    {isActive ? <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg> : stepNum}
                                </div>
                                <span className={`text-[10px] font-black uppercase tracking-wider transition-colors ${isCurrent ? 'text-emerald-600' : 'text-slate-400'}`}>{step}</span>
                            </div>
                        )
                    })}
                </div>
            </div>

            {/* Header Form */}
            <div className="p-6 md:p-8 border-b border-white/40 flex flex-col md:flex-row justify-between items-start md:items-center bg-white/40 backdrop-blur-md gap-4 shrink-0 z-20">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">{initialData ? 'Edit Data Motor' : 'Input Data Motor'}</h2>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mt-1">Job Details & Specification</p>
                </div>
                <div className="flex gap-3 w-full md:w-auto">
                    <motion.button whileTap={{scale:0.95}} type="button" onClick={onCancel} className="flex-1 md:flex-none px-6 py-3 rounded-2xl font-bold text-slate-500 bg-white/50 hover:bg-white transition-colors text-sm">Cancel</motion.button>
                    <motion.button whileTap={{scale:0.95}} onClick={handleSubmit} className="flex-1 md:flex-none px-8 py-3 bg-slate-900 text-white rounded-2xl font-bold shadow-xl shadow-slate-900/20 hover:bg-slate-800 transition-transform text-sm">Save Job</motion.button>
                </div>
            </div>
            
            {/* Main Scrollable Content */}
            <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
                
                {/* Layout Wrapper: Stacked on Mobile, Side-by-Side on XL screens */}
                <div className="flex flex-col xl:flex-row gap-8">
                    
                    {/* LEFT COLUMN: Identity & Specs (Wider) */}
                    <div className="flex-1 space-y-8">
                        
                        {/* SECTION 1: IDENTITY */}
                        <div className="bg-white/30 rounded-3xl p-6 border border-white/40">
                            <h3 className={sectionTitleStyle}>
                                <span className="numberBadgeStyle w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center text-sm font-bold shadow-lg shadow-indigo-500/30">1</span>
                                Identity Information
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className={labelStyle}>NOMOR WORK ORDER (WO)</label>
                                    
                                    {!initialData ? (
                                        // NEW ENTRY: FANCY CONFIGURATOR
                                        <div className="bg-white/40 border border-white/60 rounded-3xl p-4 shadow-sm">
                                            <div className="flex flex-col md:flex-row gap-4 items-start md:items-end">
                                                {/* 1. SALES CODE */}
                                                <div className="flex-1 w-full md:w-auto">
                                                    <label className="text-[9px] font-bold text-slate-400 ml-1 mb-1 block">Kode Sales</label>
                                                    <div className="bg-white rounded-xl border border-slate-200 px-1 py-0.5 shadow-sm">
                                                        <select 
                                                            value={woConfig.sales}
                                                            onChange={(e) => handleWoConfigChange('sales', e.target.value)}
                                                            className="w-full bg-transparent border-none text-slate-800 font-bold text-sm outline-none p-3 cursor-pointer"
                                                        >
                                                            {SALES_CODES.map(s => (
                                                                <option key={s.code} value={s.code}>{s.label}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                </div>

                                                {/* 2. SEQUENCE */}
                                                <div className="flex-[2] w-full md:w-auto">
                                                    <label className="text-[9px] font-bold text-slate-400 ml-1 mb-1 block">Nomor Urut</label>
                                                    <div className="bg-white rounded-xl border border-slate-200 px-1 py-0.5 shadow-sm">
                                                        <input 
                                                            type="number"
                                                            inputMode="numeric"
                                                            value={woConfig.sequence}
                                                            onChange={(e) => handleWoConfigChange('sequence', e.target.value)}
                                                            placeholder="Ex: 1024"
                                                            className="w-full bg-transparent border-none text-slate-800 font-bold text-sm outline-none p-3"
                                                            required
                                                        />
                                                    </div>
                                                </div>

                                                {/* 3. YEAR CODE */}
                                                <div className="w-20 md:w-24 shrink-0 flex flex-col items-center">
                                                     <div className="w-full bg-emerald-100 border border-emerald-200 rounded-xl h-[50px] flex items-center justify-center shadow-inner">
                                                        <span className="text-2xl font-black text-emerald-600">{woConfig.yearCode}</span>
                                                     </div>
                                                     <span className="text-[9px] font-bold text-emerald-600 mt-1">{new Date().getFullYear()}</span>
                                                </div>
                                            </div>

                                            {/* Preview */}
                                            <div className="mt-4 flex justify-end items-center gap-2">
                                                <span className="text-xs font-bold text-slate-400">Preview:</span>
                                                <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-lg font-black text-lg tracking-widest shadow-sm border border-indigo-100">
                                                    {woConfig.sales}<span className={!woConfig.sequence ? 'opacity-30' : ''}>{woConfig.sequence || '...'}</span>{woConfig.yearCode}
                                                </span>
                                            </div>
                                        </div>
                                    ) : (
                                        // EDIT MODE: READ ONLY INPUT
                                        <div className={inputContainerStyle}>
                                            <div className="flex items-center px-2">
                                                <span className="text-slate-400 pl-2">
                                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" /></svg>
                                                </span>
                                                <input 
                                                    name="kodeBarang" 
                                                    required
                                                    disabled
                                                    value={formData.kodeBarang} 
                                                    onChange={handleChange} 
                                                    className={`${inputStyle} text-slate-500 cursor-not-allowed`}
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div>
                                    <label className={labelStyle}>Nama Perusahaan</label>
                                    <div className={inputContainerStyle}>
                                        <div className="flex items-center px-2">
                                            <span className="text-slate-400 pl-2">
                                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                                            </span>
                                            <input 
                                                name="namaPerusahaan"
                                                required 
                                                disabled={!isAdminOrDev}
                                                value={formData.namaPerusahaan} 
                                                onChange={handleChange} 
                                                placeholder="Ex: PT. MATAHARI RAYA"
                                                className={inputStyle}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Kode Customer</label>
                                    <div className={inputContainerStyle}>
                                        <input 
                                            name="kodeCustomer" 
                                            disabled={!isAdminOrDev}
                                            value={formData.kodeCustomer} 
                                            onChange={handleChange} 
                                            placeholder="Optional"
                                            className={inputStyle}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* SECTION 2: TECH SPECS */}
                        <div className="bg-white/30 rounded-3xl p-6 border border-white/40">
                            <h3 className={sectionTitleStyle}>
                                <span className={numberBadgeStyle}>2</span>
                                Technical Specs
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                                <div>
                                    <label className={labelStyle}>Kapasitas Motor</label>
                                    <div className={inputContainerStyle}>
                                        <select 
                                            name="jenisMotor" 
                                            value={formData.jenisMotor} 
                                            onChange={handleChange}
                                            className={inputStyle}
                                            >
                                            <option value="">Select Type</option>
                                            <option value="AC MOTOR">AC MOTOR</option>
                                            <option value="DC MOTOR">DC MOTOR</option>
                                            <option value="GENERATOR">GENERATOR</option>
                                            <option value="TRANSFORMATOR">TRANSFORMATOR</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Merk / Brand</label>
                                    <div className={inputContainerStyle}>
                                        <input name="merk" value={formData.merk} onChange={handleChange} className={inputStyle} placeholder="Ex: Siemens" />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Serial Number</label>
                                    <div className={inputContainerStyle}>
                                        <input name="serialNumber" value={formData.serialNumber} onChange={handleChange} className={inputStyle} placeholder="Ex: SN-12345" />
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                                <div>
                                    <label className={labelStyle}>Daya (KW)</label>
                                    <div className={inputContainerStyle}>
                                        <input type="number" step="0.01" name="dayaKW" value={formData.dayaKW} onChange={handleChange} className={inputStyle} />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Volt</label>
                                    <div className={inputContainerStyle}>
                                        <input type="number" name="teganganVolt" value={formData.teganganVolt} onChange={handleChange} className={inputStyle} />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Hz</label>
                                    <div className={inputContainerStyle}>
                                        <input type="number" name="frekuensiHz" value={formData.frekuensiHz} onChange={handleChange} className={inputStyle} />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>RPM</label>
                                    <div className={inputContainerStyle}>
                                        <input type="number" name="rpm" value={formData.rpm} onChange={handleChange} className={inputStyle} />
                                    </div>
                                </div>
                                <div>
                                    <label className={labelStyle}>Ampere</label>
                                    <div className={inputContainerStyle}>
                                        <input type="number" step="0.1" name="arusAmpere" value={formData.arusAmpere} onChange={handleChange} className={inputStyle} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* RIGHT COLUMN: Diagnosis, Admin & Status (Narrower on XL) */}
                    <div className="w-full xl:w-[420px] space-y-8">
                        
                        {/* SECTION 3: DIAGNOSIS & CHECKLIST */}
                        <div className="bg-white/30 rounded-3xl p-6 border border-white/40">
                             <h3 className={sectionTitleStyle}>
                                <span className={numberBadgeStyle}>3</span>
                                Diagnosis
                            </h3>
                            <div className="space-y-6">
                                <div>
                                    <label className={labelStyle}>Info Customer / Keluhan</label>
                                    <div className={inputContainerStyle}>
                                        <select 
                                            value={complaintType} 
                                            onChange={handleComplaintTypeChange} 
                                            className={inputStyle}
                                        >
                                            <option value="">Select Option</option>
                                            {COMPLAINT_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                            <option value="LAINNYA">LAINNYA (Isi Manual)</option>
                                        </select>
                                    </div>
                                    
                                    <AnimatePresence>
                                        {complaintType === 'LAINNYA' && (
                                            <motion.div 
                                                initial={{ height: 0, opacity: 0, marginTop: 0 }}
                                                animate={{ height: 'auto', opacity: 1, marginTop: 8 }}
                                                exit={{ height: 0, opacity: 0, marginTop: 0 }}
                                                className="overflow-hidden"
                                            >
                                                <div className={inputContainerStyle}>
                                                    <textarea 
                                                        name="infoCustomer" 
                                                        value={formData.infoCustomer} 
                                                        onChange={handleChange} 
                                                        className="w-full bg-transparent border-none text-slate-800 font-bold placeholder-slate-300 focus:ring-0 outline-none p-3 text-sm min-h-[80px]"
                                                        placeholder="Silahkan tulis keluhan secara manual..."
                                                        autoFocus
                                                    ></textarea>
                                                </div>
                                            </motion.div>
                                        )}
                                    </AnimatePresence>
                                </div>

                                <div className="grid grid-cols-1 gap-3">
                                    {['Form Putih', 'Data Megger', 'Form Biru (QC)'].map((label, idx) => {
                                        const name = idx === 0 ? 'statusFormPutih' : idx === 1 ? 'dataMegger' : 'statusFormBiru';
                                        return (
                                            <div key={label} className="bg-white/50 px-4 py-3 rounded-2xl flex items-center justify-between border border-white/40">
                                                <label className="text-xs font-bold text-slate-600 uppercase tracking-wide">{label}</label>
                                                <select 
                                                    name={name} 
                                                    disabled={!isTeknisi} 
                                                    value={formData[name as keyof MotorData] as string} 
                                                    onChange={handleChange} 
                                                    className={`bg-transparent text-sm font-extrabold border-none focus:ring-0 outline-none text-right ${
                                                        (formData[name as keyof MotorData] as string) === 'SUDAH' ? 'text-emerald-500' : 'text-slate-400'
                                                    }`}
                                                >
                                                    <option value="BELUM">BELUM</option>
                                                    <option value="SUDAH">SUDAH</option>
                                                </select>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        </div>

                        {/* SECTION 4: DOCUMENTATION (NEW) */}
                        <div className="bg-white/30 rounded-3xl p-6 border border-white/40">
                            <h3 className={sectionTitleStyle}>
                                <span className={numberBadgeStyle}>4</span>
                                Documentation
                            </h3>
                            
                            <div className="mt-2">
                                <label className={labelStyle}>Dokumentasi Fisik</label>
                                <p className="text-[9px] text-slate-400 mb-2 leading-tight">Wajib 4-10 foto. Tersimpan di Cloudinary.</p>

                                {/* Upload Area */}
                                <div 
                                    onClick={() => fileInputRef.current?.click()}
                                    className={`border-3 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center bg-white/50 hover:bg-emerald-50 group min-h-[160px] ${
                                        previewUrls.length < 4 ? 'border-red-200' : 'border-emerald-300'
                                    }`}
                                >
                                    <input 
                                        type="file" 
                                        multiple 
                                        accept="image/*" 
                                        className="hidden" 
                                        ref={fileInputRef} 
                                        onChange={handlePhotoSelect} 
                                    />
                                    <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                                        <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                    </div>
                                    <span className="text-sm font-bold text-slate-600 group-hover:text-emerald-600">Klik Ambil / Pilih Foto</span>
                                    <span className={`text-[10px] font-bold mt-1 ${previewUrls.length < 4 ? 'text-red-500' : 'text-emerald-500'}`}>
                                        {previewUrls.length} / 10 Foto Terpilih
                                    </span>
                                </div>

                                {/* Preview Grid */}
                                {previewUrls.length > 0 && (
                                    <div className="grid grid-cols-4 gap-2 mt-3">
                                        {previewUrls.map((url, idx) => (
                                            <div key={idx} className="aspect-square relative group rounded-lg overflow-hidden border border-slate-200 shadow-sm">
                                                <img src={url} className="w-full h-full object-cover" alt="preview" />
                                                <button 
                                                    type="button"
                                                    onClick={() => removePhoto(idx)}
                                                    className="absolute top-0.5 right-0.5 bg-red-500 text-white p-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                                                >
                                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {/* Sync Footer */}
                                <div className="mt-3 bg-emerald-50 p-3 rounded-xl border border-emerald-100 flex gap-3 items-center">
                                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                                            <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-bold text-emerald-800">Auto Cloud Sync</p>
                                        <p className="text-[9px] text-emerald-600 leading-tight">Foto otomatis diberi watermark logo & disimpan di folder WO.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                         {/* SECTION 5: ADMINISTRATION */}
                        <div className="bg-white/30 rounded-3xl p-6 border border-white/40">
                             <h3 className={sectionTitleStyle}>
                                <span className={numberBadgeStyle}>5</span>
                                Admin & Commercial
                            </h3>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className={labelStyle}>Tgl Masuk</label>
                                        <div className={inputContainerStyle}>
                                            <input type="date" name="tanggalMasuk" disabled={!isAdminOrDev} value={formData.tanggalMasuk} onChange={handleChange} className={inputStyle} />
                                        </div>
                                    </div>
                                    <div>
                                        <label className={labelStyle}>Target Kirim</label>
                                        <div className={inputContainerStyle}>
                                            <input type="date" name="tanggalKirim" disabled={!isAdminOrDev} value={formData.tanggalKirim} onChange={handleChange} className={inputStyle} />
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className={labelStyle}>No Penawaran</label>
                                        <div className={inputContainerStyle}>
                                            <input name="nomorPenawaran" disabled={!isAdminOrDev} value={formData.nomorPenawaran} onChange={handleChange} className={inputStyle} placeholder='-' />
                                        </div>
                                    </div>
                                    <div>
                                        <label className={labelStyle}>No PO</label>
                                        <div className={inputContainerStyle}>
                                            <input name="nomorPO" disabled={!isAdminOrDev} value={formData.nomorPO} onChange={handleChange} className={inputStyle} placeholder='-'/>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <label className={labelStyle}>Status Utama</label>
                                    <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-1 relative">
                                        <select name="status" disabled={!isAdminOrDev} value={formData.status} onChange={handleChange} className="w-full bg-transparent border-none text-indigo-800 font-extrabold text-lg p-2 focus:ring-0 outline-none">
                                            {Object.values(MotorStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                        </select>
                                        <div className="pointer-events-none absolute inset-y-0 right-4 flex items-center px-2 text-indigo-500">
                                            <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <label className={labelStyle}>Nomor Surat Jalan</label>
                                    <div className={`${inputContainerStyle} bg-amber-50/50 border-amber-100`}>
                                        <input name="noSuratJalan" disabled={!isAdminOrDev} value={formData.noSuratJalan} onChange={handleChange} className={inputStyle} placeholder="Auto sets status to KIRIM" />
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </form>
        </motion.div>
    </div>
  );
};