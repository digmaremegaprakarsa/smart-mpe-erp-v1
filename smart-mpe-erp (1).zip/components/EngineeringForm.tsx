import React, { useState, useEffect, useRef } from 'react';
import { EngineeringData, MotorData } from '../types';
import { motion } from 'framer-motion';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

interface EngineeringFormProps {
  motors: MotorData[];
  onSave: (data: EngineeringData) => void;
  onCancel: () => void;
}

const emptyReport: EngineeringData = {
  jobNo: '', date: new Date().toISOString().split('T')[0],
  type: 'AC MOTOR', outputKW: '', voltage: '380', current: '', phase: '3', mnf: '', rpm: '', frequency: '50', serialNo: '',
  bearingDE: '', bearingNDE: '', greaseDE: '', greaseNDE: '',
  
  // Initial Insulation Defaults
  init_ins_voltage: '500', 
  init_ins_UG: '0', 
  init_ins_row2_label: 'V - G', init_ins_VG: '0', 
  init_ins_row3_label: 'W - G', init_ins_WG: '0',
  
  init_res_U1U2: '0', init_res_V1V2: '0', init_res_W1W2: '0',
  
  // Final Test Defaults
  final_noload_hz: '50',
  final_noload_connection_val: '0',
  final_noload_connection_type: 'Δ',

  final_noload_R_res: '', final_noload_R_amp: '0',
  final_noload_S_res: '', final_noload_S_amp: '0',
  final_noload_T_res: '', final_noload_T_amp: '0',
  final_rpm: '0',
  final_ins_UG: '0', final_ins_VG: '0', final_ins_WG: '0', durationRunning: '0',
  temp_ambient: '0', temp_shaftDE: '0', temp_shaftNDE: '0', temp_housingDE: '0', temp_housingNDE: '0', temp_body: '0',
  final_res_U1U2: '0', final_res_V1V2: '0', final_res_W1W2: '0',
  preparedBy: 'SALMAN', checkedBy: 'HUDA', approvedBy: 'WAHYUDI'
};

export const EngineeringForm: React.FC<EngineeringFormProps> = ({ motors, onSave, onCancel }) => {
  const [formData, setFormData] = useState<EngineeringData>(emptyReport);
  const [selectedMotor, setSelectedMotor] = useState<MotorData | null>(null);
  const [viewMode, setViewMode] = useState<'form' | 'print'>('form');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  // Handle Job No Selection to auto-fill specs
  const handleJobSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const jobNo = e.target.value;
      const motor = motors.find(m => m.kodeBarang === jobNo);
      
      if (motor) {
          setSelectedMotor(motor);
          setFormData(prev => ({
              ...prev,
              jobNo: motor.kodeBarang,
              type: motor.jenisMotor,
              mnf: motor.merk,
              outputKW: motor.dayaKW.toString(),
              voltage: motor.teganganVolt.toString(),
              current: motor.arusAmpere.toString(),
              rpm: motor.rpm.toString(),
              frequency: motor.frekuensiHz.toString(),
              serialNo: motor.serialNumber
          }));
      } else {
          setFormData(prev => ({ ...prev, jobNo }));
      }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
  };

  const inputStyle = "w-full bg-slate-50 border border-slate-200 rounded px-2 py-1.5 text-xs font-bold text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none";
  const labelStyle = "text-[10px] font-bold text-slate-400 uppercase mb-1 block";

  // Helper to display unit only if value exists
  const valWithUnit = (val: string, unit: string) => {
    if (!val) return '';
    return `${val} ${unit}`;
  };

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    setIsGeneratingPdf(true);

    try {
        const canvas = await html2canvas(reportRef.current, {
            scale: 2, // Higher scale for better quality
            backgroundColor: '#ffffff',
            useCORS: true // Ensure images load if any
        });

        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        
        const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
        
        const imgX = (pdfWidth - imgWidth * ratio) / 2;
        const imgY = 10; // Top margin

        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, (imgHeight * pdfWidth) / imgWidth);
        pdf.save(`Report_Test_${formData.jobNo || 'Draft'}.pdf`);
    } catch (error) {
        console.error("Error generating PDF", error);
        alert("Gagal membuat PDF. Silakan coba lagi.");
    } finally {
        setIsGeneratingPdf(false);
    }
  };

  // --- PRINT VIEW COMPONENT (Matches the PDF Image provided) ---
  const PrintView = () => (
      <div ref={reportRef} className="bg-white p-8 max-w-[210mm] mx-auto text-black font-serif print:p-0 text-[9pt] leading-tight min-h-[297mm]">
          
          {/* Header Company */}
          <div className="flex items-start gap-4 border-b-2 border-black pb-2 mb-2">
             <div className="w-20 h-20 flex items-center justify-center shrink-0">
                 {/* MPE Logo Placeholder */}
                 <div className="w-16 h-16 rounded-full border-4 border-red-600 flex items-center justify-center text-red-600 font-black text-xs relative overflow-hidden bg-white">
                    <div className="absolute inset-0 border-2 border-white rounded-full"></div>
                    <span className="z-10 transform -rotate-12 block">MPE</span>
                 </div>
             </div>
             <div className="flex-1 text-center pt-1">
                 <h1 className="text-xl font-black text-red-600 tracking-tight font-sans">PT. MEGA PRAKARSA ENGINEERING INDONESIA</h1>
                 <h2 className="text-[10px] font-bold text-blue-700 tracking-wide mb-1 font-sans">REWINDING MOTOR - GENERATOR - TRANSFORMER - MACHINING - PUMP SERVICES</h2>
                 <p className="text-[9px] text-slate-900 leading-snug font-sans">
                    Jalan Sunandar Priyo Sudarmo RT.02 RW.03, Sidomulyo, Kec. Krian, Kab. Sidoarjo, Jawa Timur 61262<br/>
                    Telp. 031-99893159, E-mail: emegaprakarsa@gmail.com, Website: emegaprakarsa.com
                 </p>
             </div>
          </div>

          <div className="text-center font-bold text-lg mb-2 uppercase font-sans tracking-wider">REPORT TEST</div>
          
          <div className="border-2 border-black">
              {/* Header Info */}
              <div className="flex border-b border-black">
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Job No.</div>
                  <div className="w-48 p-1 border-r border-black font-bold">{formData.jobNo}</div>
                  <div className="w-16 p-1 border-r border-black font-bold bg-gray-100">Date</div>
                  <div className="w-32 p-1 border-r border-black">{formData.date}</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">COMPANY</div>
                  <div className="flex-1 p-1 font-bold">{selectedMotor?.namaPerusahaan || '-'}</div>
              </div>

              {/* Specs Row 1 */}
              <div className="flex border-b border-black">
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Type</div>
                  <div className="flex-1 p-1">{formData.type}</div>
              </div>

              {/* Specs Row 2 */}
              <div className="flex border-b border-black">
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Output</div>
                  <div className="w-48 p-1 border-r border-black">{formData.outputKW} KW</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Voltage</div>
                  <div className="w-32 p-1 border-r border-black">{formData.voltage} V</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Current</div>
                  <div className="flex-1 p-1">{formData.current} A</div>
              </div>

               {/* Specs Row 3 */}
               <div className="flex border-b border-black">
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Phase</div>
                  <div className="w-48 p-1 border-r border-black">{formData.phase}</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Type</div>
                  <div className="w-32 p-1 border-r border-black">-</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">MNF</div>
                  <div className="flex-1 p-1">{formData.mnf}</div>
              </div>

              {/* Specs Row 4 */}
              <div className="flex border-b border-black">
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">RPM</div>
                  <div className="w-48 p-1 border-r border-black">{formData.rpm}</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">Frequency</div>
                  <div className="w-32 p-1 border-r border-black">{formData.frequency}</div>
                  <div className="w-24 p-1 border-r border-black font-bold bg-gray-100">S/No.</div>
                  <div className="flex-1 p-1">{formData.serialNo}</div>
              </div>

              {/* Bearings */}
              <div className="flex border-b border-black">
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100 text-center">Bearing Numb</div>
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100 border-l border-black">Drive End</div>
                  <div className="w-48 p-1 border-r border-black">{formData.bearingDE}</div>
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100">Non Drive End</div>
                  <div className="flex-1 p-1">{formData.bearingNDE}</div>
              </div>
              <div className="flex border-b border-black">
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100 text-center">GREASE</div>
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100 border-l border-black">Drive End</div>
                  <div className="w-48 p-1 border-r border-black">{formData.greaseDE}</div>
                  <div className="w-36 p-1 border-r border-black font-bold bg-gray-100">Non Drive End</div>
                  <div className="flex-1 p-1">{formData.greaseNDE}</div>
              </div>

              {/* INSPECTION HEADER */}
              <div className="bg-gray-200 p-1 text-center font-bold border-b border-black uppercase text-sm border-t-2 border-black">INSPECTION AND TEST RESULTS</div>
              <div className="bg-white p-1 text-center font-bold italic border-b border-black text-xs">INITIAL ELECTRICAL TEST RESULTS</div>

              {/* Initial Results */}
              <div className="flex border-b border-black">
                   <div className="w-1/2 border-r border-black text-center">
                       <div className="font-bold text-xs bg-gray-100 border-b border-black p-1">
                           WINDING INSULATION {formData.init_ins_voltage} V
                       </div>
                       <div className="p-1 border-b border-gray-300 grid grid-cols-2">
                           <span className="text-right pr-2">U - G :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_ins_UG, 'MΩ')}</span>
                       </div>
                       <div className="p-1 border-b border-gray-300 grid grid-cols-2">
                           <span className="text-right pr-2">{formData.init_ins_row2_label} :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_ins_VG, 'MΩ')}</span>
                       </div>
                       <div className="p-1 grid grid-cols-2">
                           <span className="text-right pr-2">{formData.init_ins_row3_label} :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_ins_WG, 'MΩ')}</span>
                       </div>
                   </div>
                   <div className="w-1/2 text-center">
                       <div className="font-bold text-xs bg-gray-100 border-b border-black p-1">WINDING RESISTANCE</div>
                       <div className="p-1 border-b border-gray-300 grid grid-cols-2">
                           <span className="text-right pr-2">U₁ - U₂ :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_res_U1U2, 'mΩ')}</span>
                       </div>
                       <div className="p-1 border-b border-gray-300 grid grid-cols-2">
                           <span className="text-right pr-2">V₁ - V₂ :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_res_V1V2, 'mΩ')}</span>
                       </div>
                       <div className="p-1 grid grid-cols-2">
                           <span className="text-right pr-2">W₁ - W₂ :</span> 
                           <span className="text-left font-bold">{valWithUnit(formData.init_res_W1W2, 'mΩ')}</span>
                       </div>
                   </div>
              </div>
              
              <div className="h-4 border-b border-black bg-white"></div> {/* Empty Spacer Row */}

              {/* FINAL TEST HEADER */}
              <div className="bg-gray-200 p-1 text-center font-bold border-b border-black uppercase text-sm border-t-2 border-black">FINAL TEST RESULT</div>
              
              {/* Final Test Columns */}
              <div className="flex border-b border-black">
                  {/* NO LOAD TEST SECTION */}
                  <div className="w-1/2 border-r border-black">
                      <div className="text-center font-bold text-xs italic bg-gray-100 border-b border-black p-1">NO LOAD TEST</div>
                      <div className="flex border-b border-black">
                          <div className="w-1/2 p-1 text-xs font-bold border-r border-black bg-white">Test Volt : {formData.final_noload_hz} Hz</div>
                          <div className="w-1/2 p-1 text-xs font-bold text-center bg-white">{formData.final_noload_connection_val} {formData.final_noload_connection_type} {formData.final_noload_connection_type}</div>
                      </div>
                      <div className="flex border-b border-black text-center text-xs font-bold bg-gray-100">
                          <div className="w-1/3 border-r border-black p-1">No Load Current</div>
                          <div className="w-1/3 border-r border-black p-1">No load</div>
                          <div className="w-1/3 p-1">Amp</div>
                      </div>
                      {/* R Row */}
                      <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/3 border-r border-black p-1 font-bold bg-gray-50">R</div>
                          <div className="w-1/3 border-r border-black p-1">{valWithUnit(formData.final_noload_R_res, 'V')}</div>
                          <div className="w-1/3 p-1">{valWithUnit(formData.final_noload_R_amp, 'A')}</div>
                      </div>
                      {/* S Row */}
                      <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/3 border-r border-black p-1 font-bold bg-gray-50">S</div>
                          <div className="w-1/3 border-r border-black p-1">{valWithUnit(formData.final_noload_S_res, 'V')}</div>
                          <div className="w-1/3 p-1">{valWithUnit(formData.final_noload_S_amp, 'A')}</div>
                      </div>
                      {/* T Row */}
                      <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/3 border-r border-black p-1 font-bold bg-gray-50">T</div>
                          <div className="w-1/3 border-r border-black p-1">{valWithUnit(formData.final_noload_T_res, 'V')}</div>
                          <div className="w-1/3 p-1">{valWithUnit(formData.final_noload_T_amp, 'A')}</div>
                      </div>
                       <div className="flex text-center text-sm">
                          <div className="w-1/3 border-r border-black p-1 font-bold bg-gray-50">RPM</div>
                          <div className="flex-1 p-1 font-bold">{formData.final_rpm}</div>
                      </div>
                  </div>

                  {/* INSULATION RESISTANCE SECTION */}
                  <div className="w-1/2">
                      <div className="text-center font-bold text-xs italic bg-gray-100 border-b border-black p-1">INSULATION RESISTANCE</div>
                      <div className="flex border-b border-black text-center text-xs font-bold bg-gray-100">
                          <div className="w-1/2 border-r border-black p-1">Winding Stator</div>
                          <div className="w-1/2 p-1">Kyoritsu 500 V</div>
                      </div>
                      <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/2 border-r border-black p-1 font-bold bg-gray-50">U - G</div>
                          <div className="w-1/2 p-1">{formData.final_ins_UG ? `>${formData.final_ins_UG} MΩ` : ''}</div>
                      </div>
                      <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/2 border-r border-black p-1 font-bold bg-gray-50">V - G</div>
                          <div className="w-1/2 p-1">{formData.final_ins_VG ? `>${formData.final_ins_VG} MΩ` : ''}</div>
                      </div>
                       <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/2 border-r border-black p-1 font-bold bg-gray-50">W - G</div>
                          <div className="w-1/2 p-1">{formData.final_ins_WG ? `>${formData.final_ins_WG} MΩ` : ''}</div>
                      </div>
                       <div className="flex border-b border-black text-center text-sm">
                          <div className="w-1/2 border-r border-black p-1 font-bold bg-gray-50 h-7"></div>
                          <div className="w-1/2 p-1 h-7"></div>
                      </div>
                       <div className="flex text-center text-sm">
                          <div className="w-1/2 border-r border-black p-1 font-bold bg-gray-50">Duration Running</div>
                          <div className="w-1/2 p-1">{formData.durationRunning} minutes</div>
                      </div>
                  </div>
              </div>

              {/* Temperature & Final Res */}
              <div className="flex">
                  <div className="w-2/3 border-r border-black">
                      <div className="text-center font-bold text-xs bg-gray-100 border-b border-black p-1">Temperature</div>
                      <div className="grid grid-cols-2 text-sm">
                          <div className="border-b border-r border-black p-1 font-bold bg-gray-50 pl-2">Ambient</div>
                          <div className="border-b border-black p-1 text-center">{valWithUnit(formData.temp_ambient, '°')}</div>
                          
                          <div className="border-b border-r border-black p-1 font-bold bg-gray-50 pl-2">Shaft NDE</div>
                          <div className="border-b border-black p-1 text-center">{formData.temp_shaftNDE ? '-' : ''}</div>
                          
                          <div className="border-b border-r border-black p-1 font-bold bg-gray-50 pl-2">Shaft DE</div>
                          <div className="border-b border-black p-1 text-center">{formData.temp_shaftDE ? '-' : ''}</div>
                          
                          <div className="border-b border-r border-black p-1 font-bold bg-gray-50 pl-2">Housing Bearing NDE</div>
                          <div className="border-b border-black p-1 text-center">{formData.temp_housingNDE ? '-' : ''}</div>

                          <div className="border-b border-r border-black p-1 font-bold bg-gray-50 pl-2">Housing Bearing DE</div>
                          <div className="border-b border-black p-1 text-center">{valWithUnit(formData.temp_housingDE, '°')}</div>

                          <div className="border-r border-black p-1 bg-gray-50"></div>
                          <div className="p-1"></div>

                          <div className="border-r border-black p-1 font-bold bg-gray-50 pl-2">Body</div>
                          <div className="p-1 text-center">{valWithUnit(formData.temp_body, '°')}</div>
                          <div className="p-1 border-r border-black bg-gray-50"></div><div className="p-1"></div>
                      </div>
                  </div>
                  <div className="w-1/3">
                       <div className="text-center font-bold text-xs bg-gray-100 border-b border-black p-1">Winding Resistance</div>
                       <div className="text-sm border-b border-black p-1 flex justify-between px-2 py-1 items-center">
                           <span>U₁ - U₂ :</span> <span className="font-bold">{valWithUnit(formData.final_res_U1U2, 'Ω')}</span>
                       </div>
                       <div className="text-sm border-b border-black p-1 flex justify-between px-2 py-1 items-center">
                           <span>V₁ - V₂ :</span> <span className="font-bold">{valWithUnit(formData.final_res_V1V2, 'Ω')}</span>
                       </div>
                       <div className="text-sm p-1 flex justify-between px-2 py-1 items-center">
                           <span>W₁ - W₂ :</span> <span className="font-bold">{valWithUnit(formData.final_res_W1W2, 'Ω')}</span>
                       </div>
                  </div>
              </div>
          </div>
          <div className="mt-2 text-xs text-center font-serif">Sidoarjo, {formData.date}</div>
          
          <div className="flex justify-between mt-8 px-12 text-center text-sm font-bold font-sans">
              <div>
                  <div className="mb-16">Prepared by,</div>
                  <div className="uppercase underline">{formData.preparedBy}</div>
              </div>
               <div>
                  <div className="mb-16">Checked by,</div>
                  <div className="uppercase underline">{formData.checkedBy}</div>
              </div>
               <div>
                  <div className="mb-16">Approved by,</div>
                  <div className="uppercase underline">{formData.approvedBy}</div>
              </div>
          </div>

          {/* Footer Logos Placeholder */}
          <div className="mt-8 flex justify-between items-end px-4 border-t-0 border-black pt-4">
              <div className="flex flex-col items-center">
                   <div className="text-blue-900 font-black italic text-xl tracking-tighter">MEMBER</div>
                   <div className="text-3xl font-black text-blue-900 tracking-tighter leading-none">EASA</div>
                   <div className="text-[8px] text-blue-900 font-bold">The Electro-Mechanical Authority</div>
              </div>
               <div className="flex flex-col items-center">
                   <div className="text-3xl font-black text-blue-800 tracking-tighter leading-none flex items-center gap-1">
                       <div className="w-8 h-8 rounded-full border-4 border-blue-800"></div>
                       AEMT
                   </div>
                   <div className="text-[8px] text-slate-500 font-bold">The Association of Electrical & Mechanical Trades</div>
              </div>
          </div>
      </div>
  );

  return (
    <div className="flex justify-center pb-10 h-full">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass rounded-[2.5rem] shadow-2xl border border-white/50 w-full max-w-6xl flex flex-col h-full md:h-auto overflow-hidden"
        >
            <div className="p-6 border-b border-white/40 bg-white/30 backdrop-blur-md flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                        <span className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                        </span>
                        Data Engineer
                    </h2>
                    <p className="text-xs text-slate-500 font-bold ml-10">Running Report & Technical Inspection</p>
                </div>
                <div className="flex gap-2">
                     <button 
                        onClick={() => setViewMode('form')}
                        className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${viewMode === 'form' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                     >
                        Input Data
                     </button>
                     <button 
                        onClick={() => setViewMode('print')}
                        className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${viewMode === 'print' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                     >
                        Preview Report
                     </button>
                     <button onClick={onCancel} className="px-4 py-2 rounded-xl bg-red-100 text-red-600 text-sm font-bold hover:bg-red-200">Close</button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto bg-white/50 custom-scrollbar">
                {viewMode === 'form' ? (
                    <div className="p-8 space-y-8">
                        {/* 1. Header & Specs */}
                        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                            <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">1. Header & Specifications</h3>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                                <div className="col-span-1">
                                    <label className={labelStyle}>Select Job No.</label>
                                    <select 
                                        name="jobNo" 
                                        value={formData.jobNo} 
                                        onChange={handleJobSelect}
                                        className={inputStyle}
                                    >
                                        <option value="">-- Choose Motor --</option>
                                        {motors.map(m => (
                                            <option key={m.kodeBarang} value={m.kodeBarang}>{m.kodeBarang} - {m.namaPerusahaan}</option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className={labelStyle}>Date</label>
                                    <input type="date" name="date" value={formData.date} onChange={handleChange} className={inputStyle} />
                                </div>
                                <div className="col-span-2">
                                    <label className={labelStyle}>Company</label>
                                    <input value={selectedMotor?.namaPerusahaan || ''} disabled className={`${inputStyle} bg-slate-100`} />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                                <div><label className={labelStyle}>Output (KW)</label><input name="outputKW" value={formData.outputKW} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Voltage (V)</label><input name="voltage" value={formData.voltage} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Current (A)</label><input name="current" value={formData.current} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Phase</label><input name="phase" value={formData.phase} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>RPM</label><input name="rpm" value={formData.rpm} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Freq (Hz)</label><input name="frequency" value={formData.frequency} onChange={handleChange} className={inputStyle} /></div>
                            </div>
                        </div>

                         {/* 2. Bearings */}
                         <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                            <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">2. Mechanical (Bearings)</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="space-y-4">
                                    <h4 className="font-bold text-slate-700 text-xs">Bearing Numbers</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div><label className={labelStyle}>Drive End (DE)</label><input name="bearingDE" value={formData.bearingDE} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>Non Drive End (NDE)</label><input name="bearingNDE" value={formData.bearingNDE} onChange={handleChange} className={inputStyle} /></div>
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <h4 className="font-bold text-slate-700 text-xs">Grease Type</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div><label className={labelStyle}>Drive End (DE)</label><input name="greaseDE" value={formData.greaseDE} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>Non Drive End (NDE)</label><input name="greaseNDE" value={formData.greaseNDE} onChange={handleChange} className={inputStyle} /></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 3. Initial Test */}
                        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">3. Initial Electrical Tests</h3>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <div className="flex items-center gap-2 mb-3">
                                        <h4 className="font-bold text-slate-700 text-xs">Winding Insulation</h4>
                                        <div className="flex items-center bg-white border border-slate-300 rounded px-1">
                                            <input 
                                                name="init_ins_voltage" 
                                                value={formData.init_ins_voltage} 
                                                onChange={handleChange} 
                                                className="w-12 text-xs font-bold text-right outline-none bg-transparent"
                                                placeholder="500"
                                            />
                                            <span className="text-xs font-bold text-slate-500 pl-1">V</span>
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-3 gap-2">
                                        <div>
                                            <label className={labelStyle}>U - G</label>
                                            <input name="init_ins_UG" value={formData.init_ins_UG} onChange={handleChange} className={inputStyle} />
                                        </div>
                                        <div>
                                            <select 
                                                name="init_ins_row2_label" 
                                                value={formData.init_ins_row2_label} 
                                                onChange={handleChange} 
                                                className={`${labelStyle} bg-transparent border-none p-0 cursor-pointer hover:text-indigo-600`}
                                            >
                                                <option value="V - G">V - G</option>
                                                <option value="DAR">DAR</option>
                                            </select>
                                            <input name="init_ins_VG" value={formData.init_ins_VG} onChange={handleChange} className={inputStyle} />
                                        </div>
                                        <div>
                                            <select 
                                                name="init_ins_row3_label" 
                                                value={formData.init_ins_row3_label} 
                                                onChange={handleChange} 
                                                className={`${labelStyle} bg-transparent border-none p-0 cursor-pointer hover:text-indigo-600`}
                                            >
                                                <option value="W - G">W - G</option>
                                                <option value="PI">PI</option>
                                            </select>
                                            <input name="init_ins_WG" value={formData.init_ins_WG} onChange={handleChange} className={inputStyle} />
                                        </div>
                                    </div>
                                </div>
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <h4 className="font-bold text-slate-700 text-xs mb-3">Winding Resistance (Ω)</h4>
                                    <div className="grid grid-cols-3 gap-2">
                                        <div><label className={labelStyle}>U1 - U2</label><input name="init_res_U1U2" value={formData.init_res_U1U2} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>V1 - V2</label><input name="init_res_V1V2" value={formData.init_res_V1V2} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>W1 - W2</label><input name="init_res_W1W2" value={formData.init_res_W1W2} onChange={handleChange} className={inputStyle} /></div>
                                    </div>
                                </div>
                             </div>
                        </div>

                         {/* 4. Final Test */}
                         <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">4. Final Running Test</h3>
                             
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                                 {/* No Load */}
                                 <div className="space-y-3">
                                     <h4 className="font-bold text-slate-700 text-xs">No Load Test</h4>
                                     
                                     {/* NEW: Freq & Connection Selection */}
                                     <div className="flex gap-4 mb-2">
                                        <div className="w-1/2">
                                             <label className={labelStyle}>Frequency</label>
                                             <div className="flex items-center bg-slate-50 border border-slate-200 rounded px-2">
                                                <select 
                                                    name="final_noload_hz" 
                                                    value={formData.final_noload_hz} 
                                                    onChange={handleChange}
                                                    className="w-full bg-transparent p-1.5 text-xs font-bold outline-none cursor-pointer"
                                                >
                                                    <option value="50">50 Hz</option>
                                                    <option value="60">60 Hz</option>
                                                </select>
                                             </div>
                                        </div>
                                        <div className="w-1/2">
                                             <label className={labelStyle}>Connection</label>
                                             <div className="flex items-center bg-slate-50 border border-slate-200 rounded">
                                                <input 
                                                    name="final_noload_connection_val"
                                                    value={formData.final_noload_connection_val}
                                                    onChange={handleChange}
                                                    className="w-12 p-1.5 text-xs font-bold outline-none bg-transparent text-center border-r border-slate-200"
                                                    placeholder="0"
                                                />
                                                <select 
                                                    name="final_noload_connection_type"
                                                    value={formData.final_noload_connection_type}
                                                    onChange={handleChange}
                                                    className="flex-1 bg-transparent p-1.5 text-xs font-bold outline-none cursor-pointer text-center"
                                                >
                                                    <option value="Δ">Δ (Delta)</option>
                                                    <option value="Y">Y (Star)</option>
                                                </select>
                                             </div>
                                        </div>
                                     </div>

                                     <div className="grid grid-cols-3 gap-2 items-end">
                                        <div className="text-[10px] font-bold text-center">Phase</div>
                                        <div className="text-[10px] font-bold text-center">Volt (V)</div>
                                        <div className="text-[10px] font-bold text-center">Amp (A)</div>
                                        
                                        <div className="text-xs font-bold text-center pt-2">R</div>
                                        <input name="final_noload_R_res" value={formData.final_noload_R_res} onChange={handleChange} className={inputStyle} placeholder="Volt" />
                                        <input name="final_noload_R_amp" value={formData.final_noload_R_amp} onChange={handleChange} className={inputStyle} />

                                        <div className="text-xs font-bold text-center pt-2">S</div>
                                        <input name="final_noload_S_res" value={formData.final_noload_S_res} onChange={handleChange} className={inputStyle} placeholder="Volt" />
                                        <input name="final_noload_S_amp" value={formData.final_noload_S_amp} onChange={handleChange} className={inputStyle} />

                                        <div className="text-xs font-bold text-center pt-2">T</div>
                                        <input name="final_noload_T_res" value={formData.final_noload_T_res} onChange={handleChange} className={inputStyle} placeholder="Volt" />
                                        <input name="final_noload_T_amp" value={formData.final_noload_T_amp} onChange={handleChange} className={inputStyle} />
                                     </div>
                                     <div className="mt-2">
                                          <label className={labelStyle}>Running RPM</label>
                                          <input name="final_rpm" value={formData.final_rpm} onChange={handleChange} className={inputStyle} />
                                     </div>
                                 </div>

                                 {/* Final Insulation */}
                                 <div className="space-y-3">
                                      <h4 className="font-bold text-slate-700 text-xs">Insulation Resistance</h4>
                                      <div className="flex flex-col gap-2">
                                          <div><label className={labelStyle}>U - G</label><input name="final_ins_UG" value={formData.final_ins_UG} onChange={handleChange} className={inputStyle} /></div>
                                          <div><label className={labelStyle}>V - G</label><input name="final_ins_VG" value={formData.final_ins_VG} onChange={handleChange} className={inputStyle} /></div>
                                          <div><label className={labelStyle}>W - G</label><input name="final_ins_WG" value={formData.final_ins_WG} onChange={handleChange} className={inputStyle} /></div>
                                          <div><label className={labelStyle}>Duration Run</label><input name="durationRunning" value={formData.durationRunning} onChange={handleChange} className={inputStyle} /></div>
                                      </div>
                                 </div>
                             </div>

                             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                 {/* Temp */}
                                 <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                     <h4 className="font-bold text-slate-700 text-xs mb-3">Temperature (°C)</h4>
                                     <div className="grid grid-cols-2 gap-3">
                                         <div><label className={labelStyle}>Ambient</label><input name="temp_ambient" value={formData.temp_ambient} onChange={handleChange} className={inputStyle} /></div>
                                         <div><label className={labelStyle}>Body</label><input name="temp_body" value={formData.temp_body} onChange={handleChange} className={inputStyle} /></div>
                                         <div><label className={labelStyle}>Shaft DE</label><input name="temp_shaftDE" value={formData.temp_shaftDE} onChange={handleChange} className={inputStyle} /></div>
                                         <div><label className={labelStyle}>Shaft NDE</label><input name="temp_shaftNDE" value={formData.temp_shaftNDE} onChange={handleChange} className={inputStyle} /></div>
                                         <div><label className={labelStyle}>H. Bearing DE</label><input name="temp_housingDE" value={formData.temp_housingDE} onChange={handleChange} className={inputStyle} /></div>
                                         <div><label className={labelStyle}>H. Bearing NDE</label><input name="temp_housingNDE" value={formData.temp_housingNDE} onChange={handleChange} className={inputStyle} /></div>
                                     </div>
                                 </div>
                                  {/* Final Res */}
                                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                    <h4 className="font-bold text-slate-700 text-xs mb-3">Final Winding Resistance (Ω)</h4>
                                    <div className="grid grid-cols-1 gap-2">
                                        <div><label className={labelStyle}>U1 - U2</label><input name="final_res_U1U2" value={formData.final_res_U1U2} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>V1 - V2</label><input name="final_res_V1V2" value={formData.final_res_V1V2} onChange={handleChange} className={inputStyle} /></div>
                                        <div><label className={labelStyle}>W1 - W2</label><input name="final_res_W1W2" value={formData.final_res_W1W2} onChange={handleChange} className={inputStyle} /></div>
                                    </div>
                                </div>
                             </div>
                         </div>

                          {/* 5. Signatures */}
                         <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                            <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">5. Signatures</h3>
                            <div className="grid grid-cols-3 gap-4">
                                <div><label className={labelStyle}>Prepared By</label><input name="preparedBy" value={formData.preparedBy} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Checked By</label><input name="checkedBy" value={formData.checkedBy} onChange={handleChange} className={inputStyle} /></div>
                                <div><label className={labelStyle}>Approved By</label><input name="approvedBy" value={formData.approvedBy} onChange={handleChange} className={inputStyle} /></div>
                            </div>
                        </div>

                    </div>
                ) : (
                    <div className="p-8 flex flex-col items-center">
                        <PrintView />
                        <div className="mt-8 flex gap-3">
                            <button onClick={handleExportPDF} disabled={isGeneratingPdf} className="bg-red-600 text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:bg-red-700 transition-transform hover:scale-105 flex items-center gap-2">
                                {isGeneratingPdf ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                        Generating...
                                    </>
                                ) : (
                                    <>
                                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                        Export PDF
                                    </>
                                )}
                            </button>
                            <button onClick={() => window.print()} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:bg-slate-800 transition-transform hover:scale-105 flex items-center gap-2">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                                Print Report
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </motion.div>
    </div>
  );
};