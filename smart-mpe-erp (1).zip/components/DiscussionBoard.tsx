import React, { useState, useEffect, useRef } from 'react';
import { MotorData, DiscussionMessage, UserRole, GlobalMessage } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface DiscussionBoardProps {
  motors: MotorData[];
  discussions: DiscussionMessage[];
  onViewDetail: (motor: MotorData) => void;
  currentUserRole: UserRole;
}

// Mock Global Data
const MOCK_GLOBAL_CHAT: GlobalMessage[] = [
    {
        id: 'g1',
        userName: 'Pak Heru',
        userRole: UserRole.MANAGER,
        message: 'Selamat pagi tim, mohon prioritas untuk unit TJIWI KIMIA karena sudah mendekati deadline PO.',
        timestamp: '08:00',
        isAnnouncement: true
    },
    {
        id: 'g2',
        userName: 'Agus',
        userRole: UserRole.TEKNISI,
        message: 'Siap Pak, saat ini sedang proses rewinding tahap akhir. Estimasi sore ini masuk varnish.',
        timestamp: '08:15',
        isAnnouncement: false
    },
    {
        id: 'g3',
        userName: 'Budi',
        userRole: UserRole.ADMIN,
        message: 'Jangan lupa foto dokumentasi sebelum ditutup ya Gus, buat laporan.',
        timestamp: '08:20',
        isAnnouncement: false
    }
];

export const DiscussionBoard: React.FC<DiscussionBoardProps> = ({ motors, discussions, onViewDetail, currentUserRole }) => {
    const [activeTab, setActiveTab] = useState<'threads' | 'global'>('threads');
    const [globalMessages, setGlobalMessages] = useState<GlobalMessage[]>(MOCK_GLOBAL_CHAT);
    const [newGlobalMsg, setNewGlobalMsg] = useState('');
    const globalScrollRef = useRef<HTMLDivElement>(null);

    // --- Thread Logic ---
    const threads = motors.map(motor => {
        const msgs = discussions.filter(d => d.kodeBarang === motor.kodeBarang);
        const sortedMsgs = [...msgs].reverse(); // Newest first for logic
        const latest = sortedMsgs[0];
        return { motor, lastMsg: latest, count: msgs.length };
    }).sort((a, b) => {
        if (a.lastMsg && !b.lastMsg) return -1;
        if (!a.lastMsg && b.lastMsg) return 1;
        if (a.lastMsg && b.lastMsg) return b.lastMsg.id.localeCompare(a.lastMsg.id);
        return 0;
    });

    // --- Global Chat Logic ---
    useEffect(() => {
        if (activeTab === 'global' && globalScrollRef.current) {
            globalScrollRef.current.scrollTop = globalScrollRef.current.scrollHeight;
        }
    }, [globalMessages, activeTab]);

    const handleSendGlobal = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newGlobalMsg.trim()) return;

        const isManager = currentUserRole === UserRole.MANAGER;
        
        const msg: GlobalMessage = {
            id: Date.now().toString(),
            userName: currentUserRole === UserRole.TEKNISI ? 'Agus' : currentUserRole === UserRole.ADMIN ? 'Budi' : currentUserRole === UserRole.MANAGER ? 'Pak Heru' : 'Dev',
            userRole: currentUserRole,
            message: newGlobalMsg,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isAnnouncement: isManager // Auto-flag as announcement if Manager sends it (logic can be toggled)
        };

        setGlobalMessages(prev => [...prev, msg]);
        setNewGlobalMsg('');
    };

  return (
    <div className="glass rounded-[2rem] h-[calc(100vh-140px)] flex flex-col overflow-hidden shadow-xl relative">
        
        {/* Tab Header */}
        <div className="p-4 bg-white/40 border-b border-white/50 flex gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('threads')}
                className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'threads' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'bg-white/50 text-slate-500 hover:bg-white'}`}
            >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" /></svg>
                Unit Threads
            </button>
            <button 
                onClick={() => setActiveTab('global')}
                className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'global' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'bg-white/50 text-slate-500 hover:bg-white'}`}
            >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                Workshop Square
            </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden relative">
            
            {/* VIEW 1: THREADS LIST */}
            {activeTab === 'threads' && (
                <div className="h-full flex flex-col p-6">
                    <div className="mb-4 flex items-center justify-between">
                        <div>
                            <h2 className="text-xl font-bold text-slate-800">Unit Discussions</h2>
                            <p className="text-slate-500 text-xs font-medium">Specific motor issues</p>
                        </div>
                        <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-lg text-[10px] font-bold">
                            {threads.filter(t => t.count > 0).length} Active
                        </span>
                    </div>

                    <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
                        {threads.map(({ motor, lastMsg, count }, idx) => (
                            <motion.div 
                                key={motor.kodeBarang}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.05 }}
                                onClick={() => onViewDetail(motor)}
                                className={`p-4 rounded-2xl border transition-all cursor-pointer group flex items-center justify-between gap-4 ${
                                    count > 0 ? 'bg-white hover:bg-indigo-50 border-white/50 shadow-sm' : 'bg-slate-50/50 border-transparent opacity-70'
                                }`}
                            >
                                <div className="flex items-center gap-4 min-w-0">
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 transition-colors ${
                                        count > 0 ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-400'
                                    }`}>
                                        {motor.kodeBarang.slice(0,1)}
                                    </div>
                                    <div className="min-w-0">
                                        <div className="flex items-center gap-2">
                                            <h4 className="font-bold text-slate-800 text-sm truncate">{motor.kodeBarang}</h4>
                                            <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-500 font-bold truncate max-w-[120px]">{motor.namaPerusahaan}</span>
                                        </div>
                                        <p className="text-xs text-slate-500 mt-1 truncate w-full pr-4">
                                            {lastMsg 
                                                ? <span className="text-slate-600"><span className="font-bold text-indigo-600">{lastMsg.userName}:</span> {lastMsg.message}</span> 
                                                : <span className="italic opacity-50">No messages yet</span>
                                            }
                                        </p>
                                    </div>
                                </div>
                                <div className="flex flex-col items-end gap-1 shrink-0">
                                    {lastMsg && <span className="text-[10px] font-bold text-slate-400">{lastMsg.timestamp}</span>}
                                    {count > 0 && <span className="bg-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">{count}</span>}
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            )}

            {/* VIEW 2: GLOBAL WORKSHOP SQUARE */}
            {activeTab === 'global' && (
                <div className="h-full flex flex-col bg-slate-50/50">
                    {/* Header Info */}
                    <div className="px-6 py-3 bg-white/60 backdrop-blur-sm border-b border-slate-200 flex justify-between items-center shadow-sm z-10">
                        <div>
                            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                Grup Koordinasi Bengkel
                            </h3>
                            <p className="text-[10px] text-slate-500 pl-4">Semua User Terhubung • Realtime</p>
                        </div>
                        <div className="flex -space-x-2">
                            {[1,2,3].map(i => (
                                <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-slate-200 flex items-center justify-center text-[8px] font-bold text-slate-500">U{i}</div>
                            ))}
                            <div className="w-6 h-6 rounded-full border-2 border-white bg-indigo-100 flex items-center justify-center text-[8px] font-bold text-indigo-600">+5</div>
                        </div>
                    </div>

                    {/* Chat Area */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={globalScrollRef}>
                         {globalMessages.map((msg) => {
                             const isMe = msg.userRole === currentUserRole;
                             return (
                                 <motion.div 
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    key={msg.id} 
                                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                                 >
                                     <div className={`flex items-baseline gap-2 mb-1 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                                         <span className={`text-[10px] font-black uppercase ${
                                             msg.userRole === UserRole.MANAGER ? 'text-red-500' : 
                                             msg.userRole === UserRole.ADMIN ? 'text-amber-600' :
                                             'text-indigo-600'
                                         }`}>
                                             {msg.userRole} - {msg.userName}
                                         </span>
                                         <span className="text-[9px] text-slate-400">{msg.timestamp}</span>
                                     </div>
                                     
                                     <div className={`p-3 max-w-[85%] shadow-sm text-xs font-medium relative leading-relaxed ${
                                         msg.isAnnouncement 
                                            ? 'bg-red-50 border border-red-200 text-red-900 rounded-2xl'
                                            : isMe 
                                                ? 'bg-indigo-600 text-white rounded-2xl rounded-tr-none' 
                                                : 'bg-white text-slate-700 border border-slate-200 rounded-2xl rounded-tl-none'
                                     }`}>
                                         {msg.isAnnouncement && (
                                             <div className="flex items-center gap-1 mb-1 pb-1 border-b border-red-200/50">
                                                 <svg className="w-3 h-3 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" /></svg>
                                                 <span className="text-[9px] font-bold text-red-500 uppercase">Announcement</span>
                                             </div>
                                         )}
                                         {msg.message}
                                     </div>
                                 </motion.div>
                             )
                         })}
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-white border-t border-slate-200">
                        <form onSubmit={handleSendGlobal} className="flex gap-2 items-center">
                            <input 
                                type="text" 
                                value={newGlobalMsg}
                                onChange={(e) => setNewGlobalMsg(e.target.value)}
                                placeholder="Ketik pesan untuk semua tim..." 
                                className="flex-1 bg-slate-100 border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-full px-4 py-2.5 text-sm font-medium text-slate-700 transition-all outline-none"
                            />
                            <motion.button 
                                whileTap={{ scale: 0.9 }}
                                type="submit" 
                                className="bg-indigo-600 text-white p-2.5 rounded-full hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/30 shrink-0"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                            </motion.button>
                        </form>
                    </div>
                </div>
            )}

        </div>
    </div>
  );
}