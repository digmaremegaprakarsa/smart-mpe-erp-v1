import React, { useState, useEffect, useRef } from 'react';
import { MotorData, MotorStatus, DiscussionMessage, UserRole } from '../types';
import { motion } from 'framer-motion';

interface MotorDetailProps {
  motor: MotorData;
  onBack: () => void;
  onEdit: (motor: MotorData) => void;
  discussions: DiscussionMessage[];
  onAddMessage: (msg: DiscussionMessage) => void;
  currentUserRole: UserRole;
}

export const MotorDetail: React.FC<MotorDetailProps> = ({ motor, onBack, onEdit, discussions, onAddMessage, currentUserRole }) => {
  const [newMessage, setNewMessage] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Filter messages for this specific motor
  const motorMessages = discussions.filter(d => d.kodeBarang === motor.kodeBarang);

  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [motorMessages]);

  const handleSend = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!newMessage.trim()) return;

    const msg: DiscussionMessage = {
        id: Date.now().toString(),
        kodeBarang: motor.kodeBarang,
        userName: currentUserRole === UserRole.TEKNISI ? 'Agus' : currentUserRole === UserRole.ADMIN ? 'Budi' : 'User', // Mock Name logic
        userRole: currentUserRole,
        message: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUrgent: isUrgent
    };

    onAddMessage(msg);
    setNewMessage('');
    setIsUrgent(false);
  };

  // Helper for Spec Item
  const SpecItem = ({ label, value, unit }: { label: string, value: string | number, unit?: string }) => (
      <div className="flex flex-col">
          <span className="text-slate-400 font-bold text-[10px] uppercase tracking-wide">{label}</span>
          <span className="font-bold text-slate-800 text-sm md:text-base break-words">
              {value || '-'} {value && unit ? unit : ''}
          </span>
      </div>
  );

  return (
    <div className="flex justify-center pb-10 h-full">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-[2rem] shadow-2xl border border-white/50 w-full max-w-7xl flex flex-col h-full md:h-auto overflow-hidden relative"
      >
        {/* Header - Digital Card Style */}
        <div className="bg-slate-800 p-8 text-white flex flex-col md:flex-row justify-between items-start md:items-center relative overflow-hidden shrink-0">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-10 -mt-10 pointer-events-none"></div>
            <div className="z-10">
                <div className="flex items-center gap-3 mb-2">
                    <button onClick={onBack} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg transition-colors">
                        <svg className="w-5 h-5 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                    </button>
                    <span className="text-slate-400 text-xs font-bold tracking-widest uppercase">Digital Card Information</span>
                </div>
                <h2 className="text-3xl font-bold tracking-tight mb-1 text-white">KODE: {motor.kodeBarang}</h2>
                <p className="text-slate-400 font-medium">{motor.namaPerusahaan} — {motor.jenisMotor}</p>
            </div>
            <div className="mt-4 md:mt-0 z-10 text-right">
                <span className={`px-5 py-2 rounded-full font-bold text-sm tracking-wide shadow-lg ${
                     motor.status === MotorStatus.KIRIM ? 'bg-emerald-500 text-white' :
                     motor.status === MotorStatus.ON_PROGRESS ? 'bg-amber-500 text-white' :
                     'bg-slate-50 text-white'
                }`}>
                    STATUS: {motor.status}
                </span>
            </div>
        </div>

        {/* Card Body - Grid Layout */}
        <div className="flex flex-col lg:flex-row h-full overflow-hidden">
            
            {/* LEFT: Info & Specs (Scrollable) */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-8 border-r border-slate-200/50">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    
                    {/* LEFT COLUMN CONTENT: Specs & Admin */}
                    <div className="space-y-8">
                        
                        {/* Spesifikasi Motor */}
                        <div>
                            <div className="border-b-2 border-indigo-500 pb-2 mb-4">
                                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                                    <svg className="w-5 h-5 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                                    Spesifikasi Motor
                                </h3>
                            </div>
                            
                            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm">
                                <div className="grid grid-cols-2 gap-y-6 gap-x-4">
                                    <SpecItem label="Merk" value={motor.merk} />
                                    <SpecItem label="Serial Number" value={motor.serialNumber} />
                                    <SpecItem label="Kode Customer" value={motor.kodeCustomer} />
                                    <SpecItem label="Daya" value={motor.dayaKW} unit="KW" />
                                    <SpecItem label="Tegangan" value={motor.teganganVolt} unit="V" />
                                    <SpecItem label="Ampere" value={motor.arusAmpere} unit="A" />
                                    <SpecItem label="Heartz (Hz)" value={motor.frekuensiHz} unit="Hz" />
                                    <SpecItem label="RPM" value={motor.rpm} />
                                </div>
                            </div>
                        </div>

                        {/* Info Admin (New Section) */}
                        <div>
                             <div className="border-b-2 border-slate-400 pb-2 mb-4">
                                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                                    <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                                    Info Admin
                                </h3>
                            </div>
                            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span className="text-xs font-bold text-slate-400 uppercase">No. PO</span>
                                        <span className="font-mono font-bold text-slate-800">{motor.nomorPO || '-'}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span className="text-xs font-bold text-slate-400 uppercase">Tgl Masuk</span>
                                        <span className="font-bold text-slate-800">{motor.tanggalMasuk || '-'}</span>
                                    </div>
                                     <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span className="text-xs font-bold text-slate-400 uppercase">Tgl Penawaran</span>
                                        <span className="font-bold text-slate-800">{motor.tanggalPenawaran || '-'}</span>
                                    </div>
                                     <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                                        <span className="text-xs font-bold text-slate-400 uppercase">Tgl Kirim</span>
                                        <span className="font-bold text-slate-800">{motor.tanggalKirim || '-'}</span>
                                    </div>
                                    <div className="flex justify-between items-center pt-1">
                                        <span className="text-xs font-bold text-slate-400 uppercase">No. Surat Jalan</span>
                                        <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">{motor.noSuratJalan || '-'}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    {/* RIGHT COLUMN CONTENT: Docs & Status */}
                    <div className="space-y-6">
                        
                        {/* Documentation Section */}
                        <div>
                             <div className="border-b-2 border-amber-500 pb-2 mb-4">
                                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                                    <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                    Dokumentasi
                                </h3>
                            </div>
                            <div className="w-full h-48 bg-slate-200 rounded-2xl flex items-center justify-center overflow-hidden border-4 border-white shadow-lg shrink-0 relative group mb-6">
                                {motor.dokumentasiUrl ? (
                                    <img src={motor.dokumentasiUrl} alt="Motor" className="w-full h-full object-cover" />
                                ) : (
                                    <div className="text-slate-400 flex flex-col items-center">
                                        <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                        <span className="text-[10px] font-bold">No Image</span>
                                    </div>
                                )}
                             </div>
                        </div>

                        {/* Complaint & Status */}
                        <div>
                             <div className="bg-indigo-50 rounded-2xl p-4 border border-indigo-100 mb-6">
                                <span className="text-indigo-400 font-bold text-[10px] uppercase block mb-1">Customer Info / Keluhan</span>
                                <p className="text-indigo-900 font-bold italic">"{motor.infoCustomer || 'No specific complaint'}"</p>
                            </div>

                             <div className="grid grid-cols-1 gap-2">
                                 <div className={`flex items-center gap-3 p-3 rounded-xl border ${motor.statusFormPutih === 'SUDAH' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-slate-50 border-slate-100 text-slate-400'}`}>
                                     <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black ${motor.statusFormPutih === 'SUDAH' ? 'bg-emerald-200' : 'bg-slate-200'}`}>
                                        {motor.statusFormPutih === 'SUDAH' ? '✓' : '!'}
                                     </div>
                                     <span className="text-xs font-bold">FORM PUTIH</span>
                                 </div>
                                 <div className={`flex items-center gap-3 p-3 rounded-xl border ${motor.statusFormBiru === 'SUDAH' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-red-50 border-red-100 text-red-600'}`}>
                                     <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black ${motor.statusFormBiru === 'SUDAH' ? 'bg-emerald-200' : 'bg-red-200'}`}>
                                        {motor.statusFormBiru === 'SUDAH' ? '✓' : 'X'}
                                     </div>
                                     <span className="text-xs font-bold">FORM BIRU (QC)</span>
                                 </div>
                             </div>
                        </div>
                    </div>
                </div>

                {/* Footer Buttons (Left Side) */}
                <div className="mt-8 pt-6 border-t border-slate-200 flex flex-wrap gap-3">
                    <motion.button whileTap={{ scale: 0.95 }} onClick={() => window.print()} className="bg-white border-2 border-slate-200 px-6 py-3 rounded-xl text-slate-600 font-bold hover:bg-slate-100 transition-colors flex items-center gap-2 text-sm">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                        Cetak Detail
                    </motion.button>
                    <motion.button whileTap={{ scale: 0.95 }} onClick={() => onEdit(motor)} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/30 flex items-center gap-2 text-sm">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                        Update Status
                    </motion.button>
                </div>
            </div>

            {/* RIGHT: Discussion Thread (New Feature) */}
            <div className="w-full lg:w-[400px] bg-slate-50/50 flex flex-col border-l border-slate-200/50">
                <div className="p-4 bg-slate-100/80 backdrop-blur-sm border-b border-slate-200 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <span className="bg-white p-1.5 rounded-lg shadow-sm text-indigo-500">
                             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                        </span>
                        <div>
                            <h4 className="font-bold text-slate-700 text-sm">Internal Discussion</h4>
                            <p className="text-[10px] text-slate-500 font-bold">{motorMessages.length} messages</p>
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
                    {motorMessages.length === 0 ? (
                        <div className="text-center py-10 opacity-50">
                            <p className="text-xs font-bold text-slate-400">No discussion yet.</p>
                            <p className="text-[10px] text-slate-400">Start the conversation below.</p>
                        </div>
                    ) : (
                        motorMessages.map((msg) => {
                            const isMe = msg.userRole === currentUserRole; // Simplified check
                            return (
                                <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className={`text-[10px] font-black uppercase ${isMe ? 'text-indigo-600' : 'text-slate-600'}`}>{msg.userName} ({msg.userRole})</span>
                                        <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                                    </div>
                                    <div className={`p-3 rounded-2xl text-xs font-medium max-w-[90%] shadow-sm relative ${
                                        msg.isUrgent 
                                            ? 'bg-red-50 border border-red-200 text-red-800' 
                                            : isMe 
                                                ? 'bg-indigo-600 text-white rounded-tr-none' 
                                                : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'
                                    }`}>
                                        {msg.isUrgent && <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[8px] px-1.5 py-0.5 rounded-full font-bold shadow-sm">URGENT</span>}
                                        {msg.message}
                                    </div>
                                </div>
                            )
                        })
                    )}
                </div>

                <div className="p-3 bg-white border-t border-slate-200">
                    <form onSubmit={handleSend} className="flex flex-col gap-2">
                         <div className="flex items-center gap-2 mb-1">
                             <label className="flex items-center gap-1.5 cursor-pointer">
                                 <input 
                                    type="checkbox" 
                                    checked={isUrgent}
                                    onChange={(e) => setIsUrgent(e.target.checked)}
                                    className="w-3 h-3 rounded text-red-500 focus:ring-red-500 border-slate-300" 
                                 />
                                 <span className={`text-[10px] font-bold ${isUrgent ? 'text-red-500' : 'text-slate-400'}`}>Mark Urgent</span>
                             </label>
                         </div>
                         <div className="flex gap-2">
                            <input 
                                type="text" 
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Type a message..." 
                                className="flex-1 bg-slate-100 border-transparent focus:border-indigo-300 focus:bg-white focus:ring-0 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 transition-all outline-none"
                            />
                            <button 
                                type="submit" 
                                className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/30"
                            >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                            </button>
                         </div>
                    </form>
                </div>
            </div>

        </div>
      </motion.div>
    </div>
  );
};