import React, { useState, useRef } from 'react';
import { chatWithGemini, analyzeMotorImage } from '../services/geminiService';
import { GeminiMessage } from '../types';
import { motion } from 'framer-motion';

export const GeminiTools: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'vision'>('chat');
  const [messages, setMessages] = useState<GeminiMessage[]>([
    { role: 'model', text: 'Hello! I am your AI Workshop Assistant. I can help with motor specs, diagnosis, or drafting emails.', timestamp: new Date() }
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);

  // Vision State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const newMessage: GeminiMessage = { role: 'user', text: inputText, timestamp: new Date() };
    setMessages(prev => [...prev, newMessage]);
    setInputText('');
    setLoading(true);

    const responseText = await chatWithGemini(newMessage.text);
    
    setMessages(prev => [...prev, { role: 'model', text: responseText, timestamp: new Date() }]);
    setLoading(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setAnalysisResult('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeImage = async () => {
    if (!selectedImage) return;
    setLoading(true);
    setAnalysisResult("Analyzing image components...");
    const result = await analyzeMotorImage(selectedImage, inputText); // Can pass optional prompt
    setAnalysisResult(result);
    setLoading(false);
  };

  return (
    <div className="glass rounded-[2.5rem] shadow-xl h-[calc(100vh-180px)] md:h-[calc(100vh-140px)] flex flex-col overflow-hidden relative">
      <div className="flex p-2 bg-white/40 m-4 rounded-3xl backdrop-blur-md">
        <button 
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all ${activeTab === 'chat' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-indigo-600'}`}
        >
          🤖 Chat Assistant
        </button>
        <button 
          onClick={() => setActiveTab('vision')}
          className={`flex-1 py-3 rounded-2xl text-sm font-bold transition-all ${activeTab === 'vision' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-indigo-600'}`}
        >
          📸 Vision Analysis
        </button>
      </div>

      <div className="flex-1 p-6 overflow-hidden relative pt-0">
        {activeTab === 'chat' && (
          <div className="h-full flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
              {messages.map((msg, idx) => (
                <motion.div 
                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    key={idx} 
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] rounded-3xl p-5 shadow-sm ${
                      msg.role === 'user' 
                      ? 'bg-gradient-to-br from-indigo-600 to-indigo-500 text-white rounded-br-none' 
                      : 'bg-white text-slate-700 rounded-bl-none border border-slate-100'
                  }`}>
                    <p className="whitespace-pre-wrap text-sm leading-relaxed font-medium">{msg.text}</p>
                  </div>
                </motion.div>
              ))}
              {loading && (
                  <motion.div initial={{opacity:0}} animate={{opacity:1}} className="flex justify-start">
                       <div className="bg-white/50 rounded-full px-4 py-2 text-xs font-bold text-slate-500 animate-pulse">
                           Thinking...
                       </div>
                  </motion.div>
              )}
            </div>
            <div className="flex gap-2 bg-white/60 p-2 rounded-[2rem] border border-white/50 backdrop-blur-md shadow-lg">
              <input 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask about motor winding data..."
                className="flex-1 bg-transparent border-none px-6 py-3 focus:ring-0 outline-none text-sm font-bold text-slate-700 placeholder-slate-400"
              />
              <motion.button 
                whileTap={{ scale: 0.9 }}
                onClick={handleSendMessage} 
                disabled={loading} 
                className="bg-slate-900 text-white p-4 rounded-full hover:bg-slate-800 disabled:bg-slate-300 transition-colors shadow-lg"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </motion.button>
            </div>
          </div>
        )}

        {activeTab === 'vision' && (
          <div className="h-full flex flex-col overflow-y-auto">
            <motion.div 
                whileHover={{ scale: 1.01 }}
                className="flex flex-col items-center justify-center p-10 border-2 border-dashed border-indigo-200/50 rounded-[2.5rem] bg-indigo-50/30 mb-6 transition-colors hover:bg-indigo-50/50 cursor-pointer" 
                onClick={() => fileInputRef.current?.click()}
            >
               {!selectedImage ? (
                 <>
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 text-indigo-500 shadow-md">
                    <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  </div>
                  <p className="text-slate-600 font-extrabold text-sm">Upload Photo</p>
                  <p className="text-slate-400 text-xs mt-1 font-medium">Nameplate or Damage</p>
                  <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden" />
                 </>
               ) : (
                 <div className="relative w-full flex justify-center group">
                    <img src={selectedImage} alt="Preview" className="max-h-64 rounded-3xl shadow-lg transform group-hover:scale-105 transition-transform duration-500" />
                    <button onClick={(e) => {e.stopPropagation(); setSelectedImage(null);}} className="absolute top-2 right-2 bg-white text-red-500 rounded-full p-3 shadow-xl hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-opacity">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                 </div>
               )}
            </motion.div>

            {selectedImage && (
              <div className="space-y-4">
                 <div className="bg-white/60 rounded-3xl p-2 border border-white/50">
                    <input 
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Add specific instruction (Optional)..."
                        className="w-full bg-transparent border-none px-6 py-3 focus:ring-0 outline-none text-sm font-bold text-slate-700"
                    />
                 </div>
                <motion.button 
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAnalyzeImage} 
                  disabled={loading}
                  className="w-full bg-indigo-600 text-white py-5 rounded-3xl hover:bg-indigo-700 disabled:bg-indigo-300 font-black text-lg shadow-xl shadow-indigo-500/30"
                >
                  {loading ? 'AI Analyzing...' : 'Analyze Image'}
                </motion.button>
              </div>
            )}

            {analysisResult && (
              <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} className="mt-8 p-8 bg-white/80 border border-white rounded-[2.5rem] shadow-xl backdrop-blur-xl">
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                    </div>
                    <h4 className="font-bold text-slate-800 text-lg">Analysis Result</h4>
                </div>
                <p className="whitespace-pre-wrap text-slate-600 text-sm leading-relaxed font-medium">{analysisResult}</p>
              </motion.div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};