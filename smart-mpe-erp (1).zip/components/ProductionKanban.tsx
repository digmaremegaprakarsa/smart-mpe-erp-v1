import React, { useState } from 'react';
import { MotorData, ProductionWO, TrackingMatrix, UserRole, ProductionLog } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface ProductionKanbanProps {
    motors: MotorData[];
    productionData: ProductionWO[];
    onUpdateProduction: (data: ProductionWO) => void;
    currentUserRole: UserRole;
}

const emptyMatrix: TrackingMatrix = {
    rew_stator: false, rew_rotor: false, ovh_stator: false, ovh_rotor: false, 
    dismantling: false, cleaning: false, varnish: false, assembling: false, painting: false,
    reb_de: false, reb_nde: false, js_de: false, js_nde: false,
    bal_rotor: false, part: false, qc: false, finishing: false
};

export const ProductionKanban: React.FC<ProductionKanbanProps> = ({ motors, productionData, onUpdateProduction, currentUserRole }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterDept, setFilterDept] = useState<string>('ALL');

    // Merge Data
    const combinedData = productionData.map(prod => {
        const motor = motors.find(m => m.kodeBarang === prod.kodeBarang);
        return {
            ...prod,
            motorName: motor?.namaPerusahaan || 'Unknown',
            motorType: motor?.jenisMotor || '-',
            motorKW: motor?.dayaKW || 0,
            motorRPM: motor?.rpm || 0,
        };
    }).filter(item => 
        item.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.motorName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleToggle = (wo: ProductionWO, key: keyof TrackingMatrix) => {
        // Logika Update: Toggle status True/False
        const updatedProgress = { ...wo.progress, [key]: !wo.progress[key] };
        
        const newLog: ProductionLog = {
            id: Date.now().toString(),
            action: `${key} toggled to ${!wo.progress[key]} by ${currentUserRole}`,
            user: currentUserRole,
            timestamp: new Date().toLocaleString()
        };

        const updatedWO = {
            ...wo,
            progress: updatedProgress,
            logs: [newLog, ...wo.logs]
        };

        onUpdateProduction(updatedWO);
    };

    const calculateProgress = (scope: TrackingMatrix, progress: TrackingMatrix) => {
        const keys = Object.keys(scope) as (keyof TrackingMatrix)[];
        const requiredTasks = keys.filter(k => scope[k]);
        if (requiredTasks.length === 0) return 0;
        
        const completedTasks = requiredTasks.filter(k => progress[k]).length;
        return Math.round((completedTasks / requiredTasks.length) * 100);
    };

    // Helper Component for Task Button
    const TaskBtn = ({ wo, field, label, deptContext }: { wo: ProductionWO, field: keyof TrackingMatrix, label: string, deptContext: 'winding' | 'machining' | 'mechanic' | 'qc' }) => {
        
        // 1. Check Scope (Is this task required?)
        const isRequired = (wo.jobScope || emptyMatrix)[field];
        
        // 2. Check Status (Is it done?)
        const isDone = wo.progress[field];

        // 3. Permission Logic
        const isAdmin = [UserRole.ADMIN, UserRole.DEVELOPER, UserRole.MANAGER].includes(currentUserRole);
        let hasPermission = isAdmin;
        if (!isAdmin) {
            if (deptContext === 'winding' && (currentUserRole === UserRole.TEKNISI || currentUserRole === UserRole.WINDING)) hasPermission = true;
            if (deptContext === 'machining' && currentUserRole === UserRole.MACHINING) hasPermission = true;
            if (deptContext === 'mechanic' && currentUserRole === UserRole.TEKNISI) hasPermission = true;
            if (deptContext === 'qc' && currentUserRole === UserRole.QC) hasPermission = true;
        }

        // Logic Visual & Interaksi
        // Jika tidak required -> Disable, Gray (Ghost)
        // Jika required & !Done -> Red (Pending), Clickable if Permitted
        // Jika required & Done -> Green (Done), Clickable if Permitted

        if (!isRequired) {
            return (
                <div className="w-full py-2 px-3 rounded-lg text-[10px] font-bold uppercase tracking-wide border border-slate-100 bg-slate-50 text-slate-300 flex justify-between items-center opacity-60 cursor-not-allowed">
                    <span>{label}</span>
                </div>
            );
        }

        return (
            <button
                onClick={() => hasPermission && handleToggle(wo, field)}
                disabled={!hasPermission}
                className={`
                    w-full py-2 px-3 rounded-lg text-[10px] font-bold uppercase tracking-wide border transition-all flex justify-between items-center shadow-sm
                    ${isDone 
                        ? 'bg-emerald-500 border-emerald-600 text-white hover:bg-emerald-600' // DONE (Hijau)
                        : 'bg-red-50 border-red-200 text-red-600 hover:bg-red-100 hover:border-red-300' // PENDING (Merah)
                    }
                    ${!hasPermission ? 'opacity-50 cursor-not-allowed grayscale-[0.3]' : 'cursor-pointer transform hover:scale-[1.02]'}
                `}
                title={!hasPermission ? "Akses Ditolak" : isDone ? "Selesai (Klik batal)" : "Klik Selesaikan"}
            >
                <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${isDone ? 'bg-white' : 'bg-red-400'}`}></div>
                    <span>{label}</span>
                </div>
                {isDone && <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
            </button>
        );
    };

    return (
        <div className="flex flex-col h-full gap-6 pb-20">
            {/* Header / Toolbar */}
            <div className="glass p-4 rounded-2xl flex flex-col md:flex-row justify-between items-center shadow-sm gap-4">
                <div>
                    <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                        <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                        Job Cards View
                    </h2>
                    <p className="text-xs text-slate-500 font-medium ml-8">Department Task Management</p>
                </div>
                
                <div className="flex gap-2 w-full md:w-auto">
                    <input 
                        type="text" 
                        placeholder="Cari WO / Customer..." 
                        className="bg-white/80 border-none rounded-xl py-2 px-4 text-xs font-bold shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none w-full md:w-64"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <select 
                        value={filterDept}
                        onChange={(e) => setFilterDept(e.target.value)}
                        className="bg-white/80 border-none rounded-xl py-2 px-4 text-xs font-bold shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                    >
                        <option value="ALL">All Depts</option>
                        <option value="WINDING">Winding</option>
                        <option value="MACHINING">Machining</option>
                        <option value="MECHANIC">Mechanic</option>
                        <option value="QC">QC & Finish</option>
                    </select>
                </div>
            </div>

            {/* Legend (Petunjuk Warna) */}
            <div className="flex gap-4 px-2">
                <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-100 border border-red-300 rounded"></div>
                    <span className="text-[10px] font-bold text-slate-500">PENDING (Harus Dikerjakan)</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-emerald-500 rounded"></div>
                    <span className="text-[10px] font-bold text-slate-500">DONE (Selesai)</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-slate-100 border border-slate-200 rounded"></div>
                    <span className="text-[10px] font-bold text-slate-400">N/A (Tidak Dipilih)</span>
                </div>
            </div>

            {/* Cards Grid */}
            <div className="overflow-y-auto pr-2 custom-scrollbar flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
                    {combinedData.map((wo) => {
                        const progress = calculateProgress(wo.jobScope || emptyMatrix, wo.progress);
                        return (
                            <motion.div 
                                key={wo.kodeBarang}
                                layout
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col hover:shadow-xl transition-shadow"
                            >
                                {/* Card Header */}
                                <div className="p-5 border-b border-slate-100 bg-slate-50/50">
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="bg-slate-900 text-white text-[10px] font-black px-2 py-1 rounded shadow-sm">{wo.kodeBarang}</span>
                                        <span className={`text-[10px] font-bold px-2 py-1 rounded border ${
                                            wo.priority === 'Urgent' ? 'bg-red-50 text-red-600 border-red-100' : 
                                            wo.priority === 'Normal' ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-slate-100 text-slate-500'
                                        }`}>{wo.priority}</span>
                                    </div>
                                    <h3 className="font-bold text-slate-800 text-sm truncate" title={wo.motorName}>{wo.motorName}</h3>
                                    <p className="text-[10px] text-slate-500 font-medium">{wo.motorType} • {wo.motorKW} KW • {wo.motorRPM} RPM</p>
                                    
                                    {/* Progress Bar */}
                                    <div className="mt-3 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                                        <div className={`h-full rounded-full transition-all duration-500 ${progress === 100 ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${progress}%` }}></div>
                                    </div>
                                    <div className="flex justify-between mt-1">
                                        <span className="text-[9px] font-bold text-slate-400">{progress}% Completed</span>
                                        {wo.progress.finishing && <span className="text-[9px] font-bold text-emerald-600">READY</span>}
                                    </div>
                                </div>

                                {/* Departments Scrollable Area */}
                                <div className="p-4 space-y-4 flex-1 overflow-y-auto max-h-[400px] custom-scrollbar bg-white">
                                    
                                    {/* 1. WINDING DEPT */}
                                    {(filterDept === 'ALL' || filterDept === 'WINDING') && (
                                        <div className="space-y-2">
                                            <h4 className="text-[10px] font-black text-violet-600 uppercase tracking-widest border-b border-violet-100 pb-1 mb-2">Winding Dept</h4>
                                            <div className="grid grid-cols-2 gap-2">
                                                <TaskBtn wo={wo} field="rew_stator" label="Rewind Stator" deptContext="winding" />
                                                <TaskBtn wo={wo} field="rew_rotor" label="Rewind Rotor" deptContext="winding" />
                                                <TaskBtn wo={wo} field="ovh_stator" label="Ovh Stator" deptContext="winding" />
                                                <TaskBtn wo={wo} field="ovh_rotor" label="Ovh Rotor" deptContext="winding" />
                                            </div>
                                        </div>
                                    )}

                                    {/* 2. MACHINING DEPT */}
                                    {(filterDept === 'ALL' || filterDept === 'MACHINING') && (
                                        <div className="space-y-2">
                                            <h4 className="text-[10px] font-black text-amber-600 uppercase tracking-widest border-b border-amber-100 pb-1 mb-2">Machining Dept</h4>
                                            <div className="space-y-1.5">
                                                <div className="grid grid-cols-2 gap-2">
                                                    <TaskBtn wo={wo} field="reb_de" label="Rebush DE" deptContext="machining" />
                                                    <TaskBtn wo={wo} field="reb_nde" label="Rebush NDE" deptContext="machining" />
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                    <TaskBtn wo={wo} field="js_de" label="J.Shaft DE" deptContext="machining" />
                                                    <TaskBtn wo={wo} field="js_nde" label="J.Shaft NDE" deptContext="machining" />
                                                </div>
                                                <TaskBtn wo={wo} field="bal_rotor" label="Balancing Rotor" deptContext="machining" />
                                            </div>
                                        </div>
                                    )}

                                    {/* 3. MECHANIC DEPT */}
                                    {(filterDept === 'ALL' || filterDept === 'MECHANIC') && (
                                        <div className="space-y-2">
                                            <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest border-b border-blue-100 pb-1 mb-2">Mechanic Dept</h4>
                                            <div className="grid grid-cols-2 gap-2">
                                                <TaskBtn wo={wo} field="dismantling" label="Dismantling" deptContext="mechanic" />
                                                <TaskBtn wo={wo} field="cleaning" label="Cleaning" deptContext="mechanic" />
                                                <TaskBtn wo={wo} field="varnish" label="Varnish" deptContext="mechanic" />
                                                <TaskBtn wo={wo} field="assembling" label="Assembling" deptContext="mechanic" />
                                                <TaskBtn wo={wo} field="painting" label="Painting" deptContext="mechanic" />
                                            </div>
                                        </div>
                                    )}

                                    {/* 4. QC DEPT */}
                                    {(filterDept === 'ALL' || filterDept === 'QC') && (
                                        <div className="space-y-2">
                                            <h4 className="text-[10px] font-black text-emerald-600 uppercase tracking-widest border-b border-emerald-100 pb-1 mb-2">QC & Finish</h4>
                                            <div className="grid grid-cols-3 gap-2">
                                                <TaskBtn wo={wo} field="part" label="Part" deptContext="qc" />
                                                <TaskBtn wo={wo} field="qc" label="Final QC" deptContext="qc" />
                                                <TaskBtn wo={wo} field="finishing" label="Finish" deptContext="qc" />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};