import React from 'react';
import { SalesOrder } from '../types';
import { motion } from 'framer-motion';

interface LogisticsTableProps {
  orders: SalesOrder[];
  onUpdateOrder: (order: SalesOrder) => void;
  onEdit: (order: SalesOrder) => void;
  onView: (order: SalesOrder) => void;
}

export const LogisticsTable: React.FC<LogisticsTableProps> = ({ orders, onUpdateOrder, onEdit, onView }) => {
  
  const togglePO = (order: SalesOrder) => {
      const newStatus = order.poStatus === 'Belum PO' ? 'Sudah PO' : 'Belum PO';
      onUpdateOrder({ ...order, poStatus: newStatus });
  };

  return (
    <div className="glass rounded-[2rem] flex flex-col h-[calc(100vh-140px)] overflow-hidden shadow-xl">
        <div className="p-6 border-b border-white/40 bg-white/30 backdrop-blur-sm">
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
                <span className="bg-amber-100 text-amber-600 p-2 rounded-lg">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" /></svg>
                </span>
                Pengambilan & Pengiriman
            </h2>
            <p className="text-xs text-slate-500 font-bold ml-11">Daftar permintaan pengambilan barang dari Sales.</p>
        </div>

        <div className="overflow-auto flex-1 w-full relative">
            <table className="w-full text-sm text-left border-separate border-spacing-y-3 px-4">
                <thead className="text-slate-500 font-extrabold uppercase text-[11px] tracking-wider sticky top-0 z-20">
                    <tr>
                        <th className="p-4 bg-slate-100/90 backdrop-blur-md first:rounded-l-2xl shadow-sm whitespace-nowrap sticky left-0 z-30">ACTION</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">ID Order</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Tanggal</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Nama Perusahaan</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Sales</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Jenis</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Daya (KW)</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Urgency</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md shadow-sm whitespace-nowrap">Quick Action PO</th>
                        <th className="p-4 bg-slate-50/90 backdrop-blur-md last:rounded-r-2xl shadow-sm whitespace-nowrap text-right">Status Order</th>
                    </tr>
                </thead>
                <tbody className="pb-4">
                    {orders.length === 0 ? (
                        <tr>
                            <td colSpan={10} className="text-center py-10 text-slate-400 font-bold">Belum ada order masuk.</td>
                        </tr>
                    ) : (
                        orders.map((order, index) => (
                            <motion.tr 
                                key={order.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.05 }}
                                className="bg-white hover:bg-white/80 transition-colors group shadow-sm rounded-2xl border border-transparent hover:border-indigo-100"
                            >
                                <td className="p-3 pl-4 rounded-l-2xl whitespace-nowrap sticky left-0 bg-white group-hover:bg-white/95 z-10 shadow-[4px_0_10px_-2px_rgba(0,0,0,0.05)] border-y border-l border-transparent">
                                    <div className="flex gap-2">
                                        <motion.button 
                                            whileTap={{ scale: 0.9 }}
                                            onClick={() => onView(order)}
                                            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-50 hover:bg-slate-200 text-slate-500 transition-colors"
                                            title="View Detail"
                                        >
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                        </motion.button>
                                        <motion.button 
                                            whileTap={{ scale: 0.9 }}
                                            onClick={() => onEdit(order)}
                                            className="w-9 h-9 flex items-center justify-center rounded-xl bg-indigo-50 hover:bg-indigo-200 text-indigo-600 transition-colors"
                                            title="Edit Order"
                                        >
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                        </motion.button>
                                    </div>
                                </td>
                                <td className="p-4 font-mono text-slate-600 font-bold tracking-tight">{order.id}</td>
                                <td className="p-4 text-slate-500 text-xs font-semibold">{order.timestamp}</td>
                                <td className="p-4 font-black text-slate-800">{order.customerName}</td>
                                <td className="p-4 text-slate-500 text-xs font-bold">{order.salesCode}</td>
                                <td className="p-4 text-slate-600 font-medium">{order.motorType}</td>
                                <td className="p-4 font-mono text-slate-700 font-bold">{order.dayaKW} KW</td>
                                <td className="p-4">
                                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wide border ${
                                        order.priority === 'Emergency' ? 'bg-red-50 border-red-100 text-red-600' :
                                        order.priority === 'Urgent' ? 'bg-amber-50 border-amber-100 text-amber-600' :
                                        order.priority === 'Dikerjakan Dulu' ? 'bg-blue-50 border-blue-100 text-blue-600' :
                                        'bg-slate-50 border-slate-100 text-slate-500'
                                    }`}>
                                        {order.priority}
                                    </span>
                                </td>
                                <td className="p-4">
                                    <motion.button
                                        whileTap={{ scale: 0.95 }}
                                        onClick={() => togglePO(order)}
                                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all shadow-sm flex items-center gap-1.5 ${
                                            order.poStatus === 'Sudah PO' 
                                            ? 'bg-emerald-50 border-emerald-200 text-emerald-600 hover:bg-emerald-100' 
                                            : 'bg-slate-50 border-slate-200 text-slate-400 hover:bg-slate-100 hover:text-slate-600'
                                        }`}
                                    >
                                        <span className={`w-2 h-2 rounded-full ${order.poStatus === 'Sudah PO' ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                                        {order.poStatus}
                                    </motion.button>
                                </td>
                                <td className="p-4 rounded-r-2xl text-right">
                                    <span className="text-slate-400 font-bold text-[10px] uppercase tracking-wider">{order.status}</span>
                                </td>
                            </motion.tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );
};