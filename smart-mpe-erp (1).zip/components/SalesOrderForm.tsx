import React, { useState, useEffect } from 'react';
import { SalesOrder, OrderPriority, POStatus } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface SalesOrderFormProps {
  initialData?: SalesOrder | null;
  onSave: (data: SalesOrder) => void;
  onCancel: () => void;
}

const SALES_CODES = [
    { code: 'P', label: 'P - Pusat' },
    { code: 'I', label: 'I - Ine' },
    { code: 'H', label: 'H - Hendar' },
    { code: 'R', label: 'R - Rully' }
];

const MOTOR_TYPES = ['AC MOTOR', 'GENERATOR', 'DC MOTOR', 'TRANSFORMATOR'];
const PRIORITIES: OrderPriority[] = ['Normal', 'Urgent', 'Dikerjakan Dulu', 'Emergency'];

export const SalesOrderForm: React.FC<SalesOrderFormProps> = ({ initialData, onSave, onCancel }) => {
  // ID Parts State
  const [idParts, setIdParts] = useState({
      salesCode: 'P', // Default 'P'
      sequence: '',
  });

  const [dateParts, setDateParts] = useState({
      yy: '',
      mm: ''
  });

  // Custom Input State
  const [isCustomMotorType, setIsCustomMotorType] = useState(false);

  const [formData, setFormData] = useState<Omit<Partial<SalesOrder>, 'dayaKW'> & { dayaKW: string | number }>({
    customerName: '',
    dayaKW: '', 
    motorType: 'AC MOTOR',
    priority: 'Normal',
    poStatus: 'Belum PO'
  });

  // --- AUTO SET DATE YY MM ---
  useEffect(() => {
      const now = new Date();
      const yy = now.getFullYear().toString().slice(-2); // "25" for 2025
      const mm = (now.getMonth() + 1).toString().padStart(2, '0'); // "02" for Feb
      setDateParts({ yy, mm });
  }, []);

  // --- LOAD INITIAL DATA FOR EDITING ---
  useEffect(() => {
      if (initialData) {
          // If editing, we try to parse the ID or just keep it static.
          // Since ID parsing is complex, we might just want to lock ID editing.
          setFormData({
              customerName: initialData.customerName,
              dayaKW: initialData.dayaKW,
              motorType: initialData.motorType,
              priority: initialData.priority,
              poStatus: initialData.poStatus
          });
          
          if (!MOTOR_TYPES.includes(initialData.motorType)) {
              setIsCustomMotorType(true);
          }
      }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleMotorTypeSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const val = e.target.value;
      if (val === 'LAINNYA') {
          setIsCustomMotorType(true);
          setFormData(prev => ({ ...prev, motorType: '' })); // Clear for manual input
      } else {
          setIsCustomMotorType(false);
          setFormData(prev => ({ ...prev, motorType: val }));
      }
  };

  const handleIdPartChange = (field: 'salesCode' | 'sequence', value: string) => {
      setIdParts(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!initialData && !idParts.sequence) { 
        alert("Nomor urut Order wajib diisi!"); 
        return; 
    }

    if (!formData.customerName) {
        alert("Nama Customer wajib diisi");
        return;
    }

    if (!formData.motorType) {
        alert("Jenis Motor wajib diisi");
        return;
    }

    // 1. Generate ID: "H2602115" (Code + YY + MM + Sequence)
    let finalID = '';
    let finalSalesLabel = '';

    if (initialData) {
        // KEEP EXISTING ID
        finalID = initialData.id;
        finalSalesLabel = initialData.salesCode;
    } else {
        // GENERATE NEW ID
        finalID = `${idParts.salesCode}${dateParts.yy}${dateParts.mm}${idParts.sequence}`;
        const salesObj = SALES_CODES.find(s => s.code === idParts.salesCode);
        finalSalesLabel = salesObj ? salesObj.label : idParts.salesCode;
    }

    const newOrder: SalesOrder = {
        id: finalID,
        salesCode: finalSalesLabel, 
        customerName: formData.customerName!,
        dayaKW: Number(formData.dayaKW),
        motorType: formData.motorType!,
        priority: formData.priority as OrderPriority,
        poStatus: formData.poStatus as POStatus,
        status: initialData ? initialData.status : 'Pending Pickup',
        timestamp: initialData ? initialData.timestamp : new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
    };

    onSave(newOrder);
  };

  // Styles
  const inputGroupStyle = "bg-white/50 border border-white/60 rounded-xl p-1 focus-within:ring-2 focus-within:ring-indigo-400 focus-within:bg-white transition-all shadow-sm";
  const inputStyle = "w-full bg-transparent border-none text-slate-800 font-bold placeholder-slate-400 focus:ring-0 outline-none p-3 text-sm";
  const labelStyle = "block text-[10px] font-extrabold text-slate-500 uppercase tracking-widest mb-1.5 ml-1";

  // Preview String
  const previewID = initialData ? initialData.id : `${idParts.salesCode}${dateParts.yy}${dateParts.mm}${idParts.sequence || '...'}`;

  return (
    <div className="flex justify-center items-start lg:items-center h-full pb-20 lg:pb-10 px-0 md:px-4 pt-2 lg:pt-0">
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-none md:rounded-[2rem] shadow-none md:shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col border-x-0 border-y-0 md:border md:border-white/60"
        >
            <div className="p-6 md:p-8 bg-gradient-to-br from-white/40 to-white/10">
                <div className="mb-6 border-b border-slate-200 pb-4">
                    <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
                        <span className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 shrink-0">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                        </span>
                        {initialData ? 'Edit Sales Order' : 'Sales Order Baru'}
                    </h2>
                    <p className="text-xs text-slate-500 font-bold mt-1 ml-10 uppercase tracking-wide">
                        {initialData ? 'Perbarui Data Order' : 'Input Permintaan Pengambilan Barang'}
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                    
                    {/* ID ORDER CONFIGURATION */}
                    <div className={`${initialData ? 'bg-slate-100' : 'bg-indigo-50/50'} p-4 rounded-2xl border ${initialData ? 'border-slate-200' : 'border-indigo-100/50'}`}>
                        <label className={labelStyle}>KONFIGURASI ID ORDER</label>
                        
                        {!initialData ? (
                            // CREATE MODE: CONFIGURABLE
                            <div className="flex gap-2 items-center">
                                {/* 1. SALES CODE */}
                                <div className="w-1/3 min-w-[140px]">
                                    <select 
                                        value={idParts.salesCode}
                                        onChange={(e) => handleIdPartChange('salesCode', e.target.value)}
                                        className={`${inputGroupStyle} w-full text-sm font-bold text-slate-800 outline-none p-3 cursor-pointer`}
                                    >
                                        {SALES_CODES.map(s => (
                                            <option key={s.code} value={s.code}>{s.label}</option>
                                        ))}
                                    </select>
                                    <p className="text-[9px] text-slate-400 mt-1 ml-1">Kode Sales</p>
                                </div>

                                {/* 2. AUTO DATE (YY MM) */}
                                <div className="w-24">
                                    <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-center h-[46px] shadow-sm">
                                        <span className="text-slate-600 font-mono font-bold text-sm tracking-widest">{dateParts.yy}{dateParts.mm}</span>
                                    </div>
                                    <p className="text-[9px] text-slate-400 mt-1 text-center font-bold">Thn Bln</p>
                                </div>

                                {/* 3. SEQUENCE NUMBER */}
                                <div className="flex-1">
                                    <input 
                                        type="number"
                                        inputMode="numeric"
                                        value={idParts.sequence}
                                        onChange={(e) => handleIdPartChange('sequence', e.target.value)}
                                        placeholder="No. Urut (Ex: 115)"
                                        className={`${inputGroupStyle} w-full text-sm font-bold text-slate-800 p-3 outline-none`}
                                        autoFocus
                                        required
                                    />
                                    <p className="text-[9px] text-slate-400 mt-1 ml-1">Nomor Urut</p>
                                </div>
                            </div>
                        ) : (
                            // EDIT MODE: LOCKED
                            <div className="flex items-center gap-3">
                                <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-sm w-full">
                                    <span className="font-mono font-black text-xl text-slate-700 tracking-widest">{initialData.id}</span>
                                </div>
                                <span className="text-xs font-bold text-slate-400 italic">ID Locked</span>
                            </div>
                        )}

                        {!initialData && (
                            <div className="mt-3 pt-3 border-t border-indigo-100 flex justify-between items-center">
                                <span className="text-xs font-bold text-indigo-400">Generated ID:</span>
                                <div className="text-lg font-black text-indigo-600 bg-white px-4 py-1.5 rounded-lg shadow-sm tracking-widest border border-indigo-100">
                                    {previewID}
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Customer Name */}
                        <div>
                            <label className={labelStyle}>Nama Customer / Perusahaan</label>
                            <div className={inputGroupStyle}>
                                <input 
                                    name="customerName"
                                    value={formData.customerName}
                                    onChange={handleChange}
                                    placeholder="PT. Matahari Raya"
                                    className={inputStyle}
                                    required
                                />
                            </div>
                        </div>

                         {/* Motor Type */}
                        <div>
                            <label className={labelStyle}>Jenis Motor</label>
                            <div className={inputGroupStyle}>
                                <select 
                                    value={isCustomMotorType ? 'LAINNYA' : formData.motorType} 
                                    onChange={handleMotorTypeSelect} 
                                    className={inputStyle}
                                >
                                    {MOTOR_TYPES.map(t => (
                                        <option key={t} value={t}>{t}</option>
                                    ))}
                                    <option value="LAINNYA">LAINNYA (Isi Manual)</option>
                                </select>
                            </div>
                            
                            {/* Manual Input Animation */}
                            <AnimatePresence>
                                {isCustomMotorType && (
                                    <motion.div
                                        initial={{ height: 0, opacity: 0, marginTop: 0 }}
                                        animate={{ height: 'auto', opacity: 1, marginTop: 8 }}
                                        exit={{ height: 0, opacity: 0, marginTop: 0 }}
                                        className="overflow-hidden"
                                    >
                                        <div className={`${inputGroupStyle} bg-indigo-50/50 border-indigo-200`}>
                                            <input 
                                                name="motorType"
                                                value={formData.motorType} 
                                                onChange={handleChange} 
                                                placeholder="Ketik jenis motor di sini..."
                                                className={`${inputStyle} text-indigo-700`}
                                                autoFocus
                                                required={isCustomMotorType}
                                            />
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Daya KW */}
                        <div>
                             <label className={labelStyle}>Daya (KW)</label>
                             <div className={inputGroupStyle}>
                                <input 
                                    type="number" 
                                    step="0.01" 
                                    name="dayaKW" 
                                    value={formData.dayaKW} 
                                    onChange={handleChange} 
                                    placeholder="Contoh: 20" 
                                    className={inputStyle} 
                                />
                             </div>
                        </div>

                        {/* Priority */}
                        <div>
                            <label className={labelStyle}>Status Motor (Urgency)</label>
                            <div className={`${inputGroupStyle} ${
                                formData.priority === 'Emergency' ? 'bg-red-50 ring-1 ring-red-200' : 
                                formData.priority === 'Urgent' ? 'bg-amber-50 ring-1 ring-amber-200' : ''
                            }`}>
                                <select name="priority" value={formData.priority} onChange={handleChange} className={inputStyle}>
                                    {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="bg-slate-50/50 p-4 rounded-2xl border border-white/50">
                        <div className="grid grid-cols-1 gap-4">
                            {/* PO Status */}
                            <div>
                                <label className={labelStyle}>Status PO</label>
                                <div className={`${inputGroupStyle} ${
                                    formData.poStatus === 'Sudah PO' ? 'bg-emerald-50 ring-1 ring-emerald-200' : ''
                                }`}>
                                    <select name="poStatus" value={formData.poStatus} onChange={handleChange} className={inputStyle}>
                                        <option value="Belum PO">Belum PO</option>
                                        <option value="Sudah PO">Sudah PO</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                        <button type="button" onClick={onCancel} className="flex-1 py-3 rounded-xl font-bold text-slate-500 hover:bg-slate-100 transition-colors text-sm">Batal</button>
                        <button 
                            type="submit" 
                            className="flex-[2] py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 transition-all text-sm flex items-center justify-center gap-2"
                        >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                            {initialData ? 'Update Order' : 'Kirim Order'}
                        </button>
                    </div>
                </form>
            </div>
        </motion.div>
    </div>
  );
};