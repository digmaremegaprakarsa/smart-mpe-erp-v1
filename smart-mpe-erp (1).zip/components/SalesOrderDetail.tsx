import React from 'react';
import { SalesOrder } from '../types';
import { motion } from 'framer-motion';

interface SalesOrderDetailProps {
  order: SalesOrder;
  onBack: () => void;
  onEdit: (order: SalesOrder) => void;
}

export const SalesOrderDetail: React.FC<SalesOrderDetailProps> = ({ order, onBack, onEdit }) => {
  return (
    <div className="flex justify-center items-center h-full pb-10 px-4">
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-[2rem] shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col border border-white/60"
        >
            <div className="p-8 bg-gradient-to-r from-slate-800 to-slate-900 text-white flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-black flex items-center gap-3">
                        <span className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-white backdrop-blur-sm">
                             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                        </span>
                        {order.id}
                    </h2>
                    <p className="text-slate-400 font-bold mt-1 ml-14 uppercase tracking-wider">Sales Order Detail</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                     <span className={`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider ${
                        order.poStatus === 'Sudah PO' ? 'bg-emerald-500 text-white' : 'bg-slate-600 text-slate-300'
                     }`}>
                        {order.poStatus}
                     </span>
                     <span className="text-xs font-mono text-slate-400">{order.timestamp}</span>
                </div>
            </div>

            <div className="p-8 bg-white/50 backdrop-blur-sm">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Left Column */}
                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                             <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4">Customer Info</h3>
                             <div className="space-y-4">
                                <div>
                                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Perusahaan</label>
                                    <p className="text-xl font-black text-slate-800">{order.customerName}</p>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Sales Person</label>
                                    <div className="flex items-center gap-2">
                                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs">
                                            {order.salesCode.charAt(0)}
                                        </div>
                                        <p className="text-sm font-bold text-slate-700">{order.salesCode}</p>
                                    </div>
                                </div>
                             </div>
                        </div>

                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                             <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4">Status & Urgency</h3>
                             <div className="flex flex-col gap-3">
                                 <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
                                     <span className="text-sm font-bold text-slate-500">Urgency Level</span>
                                     <span className={`px-3 py-1 rounded-full text-xs font-black uppercase ${
                                        order.priority === 'Emergency' ? 'bg-red-100 text-red-600' :
                                        order.priority === 'Urgent' ? 'bg-amber-100 text-amber-600' :
                                        order.priority === 'Dikerjakan Dulu' ? 'bg-blue-100 text-blue-600' :
                                        'bg-slate-200 text-slate-500'
                                     }`}>{order.priority}</span>
                                 </div>
                                 <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
                                     <span className="text-sm font-bold text-slate-500">Order Status</span>
                                     <span className="font-bold text-slate-800">{order.status}</span>
                                 </div>
                             </div>
                        </div>
                    </div>

                    {/* Right Column */}
                     <div className="space-y-6">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-full">
                             <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4">Technical Specs</h3>
                             <div className="grid grid-cols-2 gap-6">
                                 <div>
                                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Jenis Motor</label>
                                    <p className="text-lg font-bold text-indigo-900">{order.motorType}</p>
                                 </div>
                                 <div>
                                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Daya</label>
                                    <p className="text-3xl font-black text-slate-800">{order.dayaKW} <span className="text-sm text-slate-400 font-medium">KW</span></p>
                                 </div>
                             </div>
                             
                             <div className="mt-8 pt-8 border-t border-slate-100">
                                 <div className="bg-indigo-50 p-4 rounded-xl flex gap-4 items-center">
                                     <svg className="w-8 h-8 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                     <div>
                                         <p className="text-[10px] font-bold text-indigo-400 uppercase">System Note</p>
                                         <p className="text-xs font-bold text-indigo-800">Pastikan unit fisik sesuai dengan spesifikasi di atas saat pengambilan.</p>
                                     </div>
                                 </div>
                             </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/60 flex gap-4">
                    <button 
                        onClick={onBack}
                        className="flex-1 py-3 rounded-xl font-bold text-slate-500 bg-white hover:bg-slate-100 transition-colors shadow-sm"
                    >
                        Kembali
                    </button>
                    <button 
                        onClick={() => onEdit(order)}
                        className="flex-1 py-3 rounded-xl font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/30 flex items-center justify-center gap-2"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                        Edit Order
                    </button>
                </div>
            </div>
        </motion.div>
    </div>
  );
};